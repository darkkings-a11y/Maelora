# Maelora
Application de tirage de cartes (Android, Kotlin, sans dépendance externe). Le workflow `build.yml` la détecte via `settings.gradle.kts` et produit l'APK debug.
- Accueil : 3 carrés (Tarot de Marseille, Oracle du mage Edmond, Oracle des anciens dieux) — jaquettes dans `assets/jaquettes/`
- Chaque jeu propose ses tirages (`Decks.kt`), puis le tirage et la page de chaque carte
- Oracle du mage Edmond : 53 cartes dans `assets/cartes/edmond/`, textes dans `Edmond.kt`
- Oracle des anciens dieux : 44 cartes dans `assets/cartes/dieux/`, textes dans `Dieux.kt` (chaque carte a une famille ; 3 tirages : Miroir, Balance des Mondes, Voie des 14)
- `Resume.kt` : résumé clair du tirage (ambiance, histoire, accords et tensions, conseil), affiché avant le détail carte par carte
- Tarot de Marseille : 74 cartes dans `assets/cartes/`, textes dans `Data.kt`
