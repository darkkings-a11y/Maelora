package com.maelora.arcanes

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class DeckActivity : Activity() {
    private fun dp(v: Int): Int = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val di = intent.getIntExtra("deck", 0).coerceIn(0, DECKS.size - 1)
        val deck = DECKS[di]
        val root = FrameLayout(this)
        root.addView(BackgroundView(this, di + 1), ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(16), dp(48), dp(16), dp(32))
        col.addView(Ui.brand(this))
        col.addView(Ui.txt(this, deck.nom, 28f, Pal.creme, true))
        val intro = Ui.txt(this, deck.intro, 16f, Pal.creme, false)
        intro.setPadding(0, dp(8), 0, dp(8))
        col.addView(intro)
        if (deck.cartes.isEmpty()) {
            col.addView(Ui.txt(this, "Les cartes de ce jeu arrivent bientôt.", 15f, Pal.gold, false))
        }
        if (deck.regles.isNotEmpty()) {
            val pr = LinearLayout(this)
            pr.orientation = LinearLayout.VERTICAL
            pr.setPadding(dp(18), dp(14), dp(18), dp(14))
            pr.background = Ui.rond(this, android.graphics.Color.parseColor("#E00C0A1D"), 16, true)
            val tr = Ui.txt(this, "Les règles de l'oracle", 19f, Pal.gold, true)
            tr.gravity = Gravity.START
            pr.addView(tr)
            val tx = Ui.txt(this, deck.regles, 15f, Pal.creme, false)
            tx.gravity = Gravity.START
            tx.setLineSpacing(0f, 1.15f)
            tx.setPadding(0, dp(6), 0, 0)
            pr.addView(tx)
            val lpr = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lpr.topMargin = dp(12)
            col.addView(pr, lpr)
        }
        val titre = Ui.txt(this, "Choisissez votre tirage", 18f, Pal.gold, true)
        titre.setPadding(0, dp(20), 0, dp(8))
        col.addView(titre)
        deck.tirages.forEachIndexed { i, t ->
            val panel = LinearLayout(this)
            panel.orientation = LinearLayout.VERTICAL
            panel.setPadding(dp(18), dp(14), dp(18), dp(14))
            panel.background = Ui.rond(this, android.graphics.Color.parseColor("#E00C0A1D"), 16, true)
            val nom = Ui.txt(this, t.nom, 19f, Pal.gold, true)
            nom.gravity = Gravity.START
            panel.addView(nom)
            val d = Ui.txt(this, t.desc, 15f, Pal.creme, false)
            d.gravity = Gravity.START
            panel.addView(d)
            val n = Ui.txt(this, "${t.positions.size} carte" + (if (t.positions.size > 1) "s" else ""), 13f, Pal.gold, false)
            n.gravity = Gravity.START
            panel.addView(n)
            panel.setOnClickListener {
                startActivity(Intent(this, TirageActivity::class.java).putExtra("deck", di).putExtra("tirage", i))
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            col.addView(panel, lp)
        }
        scroll.addView(col)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }
}
