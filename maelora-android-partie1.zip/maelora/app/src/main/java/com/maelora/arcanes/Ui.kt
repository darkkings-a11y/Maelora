package com.maelora.arcanes

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun txt(ctx: Context, t: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(ctx)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        tv.setTypeface(Typeface.SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        tv.gravity = Gravity.CENTER
        return tv
    }

    fun rond(ctx: Context, color: Int, r: Int, stroke: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(ctx, r).toFloat()
        if (stroke) g.setStroke(dp(ctx, 1), Pal.gold)
        return g
    }

    fun brand(ctx: Context): TextView {
        val tv = txt(ctx, "MAELORA", 13f, Pal.gold, true)
        tv.letterSpacing = 0.3f
        tv.setPadding(0, 0, 0, dp(ctx, 12))
        return tv
    }
}
