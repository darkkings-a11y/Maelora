package com.maelora.arcanes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

class BackgroundView(ctx: Context, private var theme: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cream = Color.parseColor("#F3E2A6")
    private val skies = arrayOf(
        intArrayOf(Color.parseColor("#2A1A5E"), Color.parseColor("#07061A")),
        intArrayOf(Color.parseColor("#12304F"), Color.parseColor("#050A1A")),
        intArrayOf(Color.parseColor("#3B1450"), Color.parseColor("#0A0415")),
        intArrayOf(Color.parseColor("#1D2A63"), Color.parseColor("#060818")),
        intArrayOf(Color.parseColor("#102A4A"), Color.parseColor("#040612"))
    )

    fun setTheme(t: Int) {
        theme = t
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = skies[theme % skies.size]
        p.style = Paint.Style.FILL
        p.pathEffect = null
        p.shader = RadialGradient(w / 2, h * 0.25f, max(w, h), s[0], s[1], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        val r = Random(theme * 7L + 1L)
        for (i in 0 until 150) {
            p.color = Color.argb(80 + r.nextInt(175), 255, 244, 207)
            c.drawCircle(r.nextFloat() * w, r.nextFloat() * h, 0.8f + r.nextFloat() * 2.2f, p)
        }
        when (theme % 5) {
            0 -> pleineLune(c, w, h)
            1 -> croissant(c, w, h)
            2 -> eclipse(c, w, h)
            3 -> phases(c, w, h)
            else -> aurore(c, w, h)
        }
    }

    private fun halo(c: Canvas, cx: Float, cy: Float, rad: Float) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, rad, Color.argb(150, 255, 242, 196), Color.argb(0, 255, 242, 196), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad, p)
        p.shader = null
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, rad: Float, alpha: Int, width: Float) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = width
        p.color = Color.argb(alpha, 217, 180, 90)
        c.drawCircle(cx, cy, rad, p)
        p.style = Paint.Style.FILL
    }

    private fun crescent(c: Canvas, cx: Float, cy: Float, rad: Float, shift: Float, color: Int) {
        val a = Path()
        a.addCircle(cx, cy, rad, Path.Direction.CW)
        val b = Path()
        b.addCircle(cx + shift, cy - rad * 0.08f, rad * 0.82f, Path.Direction.CW)
        a.op(b, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = color
        c.drawPath(a, p)
    }

    private fun pleineLune(c: Canvas, w: Float, h: Float) {
        val cx = w / 2
        val cy = h * 0.22f
        halo(c, cx, cy, w * 0.9f)
        for (i in 0..4) ring(c, cx, cy, w * 0.28f + i * w * 0.14f, 140 - i * 22, 2f)
        p.style = Paint.Style.FILL
        p.color = cream
        c.drawCircle(cx, cy, w * 0.2f, p)
        p.color = Color.argb(90, 190, 165, 100)
        c.drawCircle(cx - w * 0.06f, cy - w * 0.04f, w * 0.03f, p)
        c.drawCircle(cx + w * 0.05f, cy + w * 0.05f, w * 0.04f, p)
        c.drawCircle(cx + w * 0.07f, cy - w * 0.08f, w * 0.018f, p)
    }

    private fun croissant(c: Canvas, cx0: Float, cy0: Float) {
        val w = cx0
        val h = cy0
        halo(c, w * 0.72f, h * 0.14f, w * 0.7f)
        crescent(c, w * 0.72f, h * 0.14f, w * 0.22f, w * 0.1f, cream)
        val pts = arrayOf(0.1f to 0.34f, 0.3f to 0.27f, 0.22f to 0.43f, 0.5f to 0.36f, 0.7f to 0.5f, 0.88f to 0.4f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = Color.argb(140, 217, 180, 90)
        for (i in 0 until pts.size - 1) {
            c.drawLine(pts[i].first * w, pts[i].second * h, pts[i + 1].first * w, pts[i + 1].second * h, p)
        }
        for (q in pts) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#FFF4CF")
            c.drawCircle(q.first * w, q.second * h, 5f, p)
            ring(c, q.first * w, q.second * h, 14f, 150, 1.5f)
        }
    }

    private fun eclipse(c: Canvas, w: Float, h: Float) {
        val cx = w / 2
        val cy = h * 0.25f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = Color.argb(70, 217, 180, 90)
        for (i in 0 until 40) {
            val a = 2 * PI * i / 40
            c.drawLine(cx, cy, cx + (cos(a) * w * 1.2).toFloat(), cy + (sin(a) * w * 1.2).toFloat(), p)
        }
        halo(c, cx, cy, w * 0.6f)
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#07040F")
        c.drawCircle(cx, cy, w * 0.21f, p)
        ring(c, cx, cy, w * 0.21f, 230, 12f)
        ring(c, cx, cy, w * 0.3f, 110, 2f)
    }

    private fun phases(c: Canvas, w: Float, h: Float) {
        val cx = w / 2
        val cy = h * 0.25f
        halo(c, cx, cy, w * 0.8f)
        for (i in 0..6) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f
            p.color = Color.argb(140, 217, 180, 90)
            p.pathEffect = DashPathEffect(floatArrayOf(6f + i * 5f, 14f), 0f)
            c.drawCircle(cx, cy, w * 0.12f + i * w * 0.07f, p)
        }
        p.pathEffect = null
        p.style = Paint.Style.FILL
        p.color = cream
        c.drawCircle(cx, cy, w * 0.09f, p)
        val rr = w * 0.045f
        for (i in 0..6) {
            val x = w * 0.5f + (i - 3) * w * 0.13f
            val y = h * 0.88f
            ring(c, x, y, rr, 90, 1.5f)
            val lit = Path()
            lit.addCircle(x, y, rr, Path.Direction.CW)
            val sh = Path()
            sh.addCircle(x + 2.1f * rr * (i / 6f), y, rr, Path.Direction.CW)
            lit.op(sh, Path.Op.DIFFERENCE)
            p.style = Paint.Style.FILL
            p.color = cream
            c.drawPath(lit, p)
        }
    }

    private fun aurore(c: Canvas, w: Float, h: Float) {
        val cols = intArrayOf(Color.argb(60, 62, 224, 176), Color.argb(60, 122, 92, 255), Color.argb(60, 214, 92, 255), Color.argb(60, 74, 168, 255))
        for (i in 0..3) {
            val y0 = h * (0.3f + i * 0.08f)
            val path = Path()
            path.moveTo(0f, y0)
            path.cubicTo(w * 0.3f, y0 - h * 0.12f, w * 0.6f, y0 + h * 0.12f, w, y0 - h * 0.05f)
            path.lineTo(w, h)
            path.lineTo(0f, h)
            path.close()
            p.style = Paint.Style.FILL
            p.color = cols[i]
            c.drawPath(path, p)
        }
        halo(c, w * 0.2f, h * 0.1f, w * 0.4f)
        p.style = Paint.Style.FILL
        p.color = cream
        c.drawCircle(w * 0.2f, h * 0.1f, w * 0.07f, p)
    }
}
