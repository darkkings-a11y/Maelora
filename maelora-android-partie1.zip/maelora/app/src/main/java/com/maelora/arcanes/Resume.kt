package com.maelora.arcanes

/**
 * Génère le résumé clair d'un tirage, affiché AVANT le détail carte par carte.
 * Fonctionne pour tous les jeux et tous les tirages : il s'appuie sur la position
 * de chaque carte, ses mots-clés (Carte.m) et son conseil (Carte.c).
 */
object Resume {
    private const val GOLD = "#D9B45A"

    private val SUITS = listOf(
        "Bâtons" to "l'action, l'énergie et les projets",
        "Coupes" to "les émotions et les relations",
        "Épées" to "les pensées, la vérité et les décisions",
        "Deniers" to "le concret : le travail, l'argent et la sécurité"
    )

    // Oracle du mage Edmond : la planète se lit dans le nom du fichier (edmond/jupiter_xxx.jpg).
    private val PLANETES = listOf(
        "Soleil" to "la réussite, la joie et la reconnaissance",
        "Lune" to "les émotions, les mouvements et les zones d'ombre",
        "Mars" to "les conflits, l'énergie brute et les épreuves",
        "Mercure" to "la communication, l'argent et les affaires",
        "Jupiter" to "la chance, la sagesse et les appuis",
        "Vénus" to "l'amour, la famille et les plaisirs de la vie",
        "Saturne" to "les freins, les épreuves et le temps qui passe"
    )

    // Oracle des anciens dieux : les 11 familles transversales (champ Carte.f).
    private val FAMILLES = listOf(
        "Ciel" to "l'autorité, l'ordre et la vision d'ensemble",
        "Tempête" to "le mouvement, le souffle et les bouleversements",
        "Sagesse" to "la sagesse, l'intuition et les mondes invisibles",
        "Passion" to "la passion, le feu intérieur et l'énergie vitale",
        "Quête" to "la quête, le courage et la persévérance",
        "Lumière" to "la lumière, la justice et la clarté qui guide",
        "Ombre" to "l'ombre, l'introspection et le passage des âmes",
        "Joie" to "la joie, l'abondance et le plaisir de vivre",
        "Terre" to "la terre, l'ancrage et le soin de ce qui nous nourrit",
        "Création" to "la création, le geste fondateur et la renaissance",
        "Protection" to "la protection, la vigilance et la garde des limites"
    )

    // Forces contraires : quand elles se font face, c'est un combat (tension).
    private val TENSIONS = listOf(
        "Tempête" to "Sagesse",
        "Tempête" to "Terre",
        "Lumière" to "Ombre",
        "Passion" to "Protection",
        "Ciel" to "Quête"
    )

    private val THEMES = SUITS + PLANETES + FAMILLES

    private fun estEdmond(c: Carte): Boolean = c.img.startsWith("edmond/")

    private fun planeteOf(c: Carte): String? {
        if (!estEdmond(c)) return null
        val k = c.img.substringAfter("edmond/").substringBefore("_")
        return PLANETES.firstOrNull { it.first.lowercase().replace("é", "e") == k }?.first
    }

    private fun suitOf(c: Carte): String? = SUITS.firstOrNull { c.nom.contains(it.first) }?.first

    private fun themeOf(c: Carte): String? = if (c.f.isNotEmpty()) c.f else (suitOf(c) ?: planeteOf(c))

    private fun estOracle(c: Carte): Boolean = estEdmond(c) || c.f.isNotEmpty()

    private fun enTension(a: String, b: String): Boolean =
        TENSIONS.any { (it.first == a && it.second == b) || (it.first == b && it.second == a) }

    private fun phraseTheme(t: String): String = THEMES.firstOrNull { it.first == t }?.second ?: t

    /** Panthéon d'une carte de l'oracle des anciens dieux (sumerien, indien, chinois, egyptien). */
    private fun pantheon(c: Carte): String =
        if (c.img.startsWith("dieux/")) c.img.substringAfter("dieux/").substringBefore("_") else ""

    private fun isFondatrice(c: Carte): Boolean = c.img.startsWith("edmond/fondatrice_")

    // Arcane majeur : uniquement pour le tarot (les cartes de l'oracle d'Edmond n'en sont pas).
    private fun isMajeur(c: Carte): Boolean = !estOracle(c) && suitOf(c) == null

    /** Deux premiers mots-clés de la carte, reliés par « et ». */
    private fun mots(c: Carte): String {
        val k = c.m.split(", ").map { it.trim() }.filter { it.isNotEmpty() }
        return when {
            k.isEmpty() -> c.m
            k.size == 1 -> k[0]
            else -> k[0] + " et " + k[1]
        }
    }

    /** Une phrase naturelle selon la position de la carte dans le tirage. */
    private fun phrase(pos: String, c: Carte): String {
        val k = mots(c)
        val p = pos.lowercase()
        return when {
            p == "le message" -> "Le message que les cartes vous envoient : $k."
            p == "passé" || p == "le passé" -> "Dans votre passé, je vois $k."
            p == "présent" || p == "le présent" -> "En ce moment, les cartes me montrent $k."
            p == "futur" || p == "l'avenir" -> "Devant vous, je vois venir $k."
            p.contains("avenir proche") -> "Dans les prochains temps, les cartes annoncent $k."
            p.contains("passé récent") -> "Récemment, vous avez traversé $k."
            p == "vous" -> "En vous, les cartes révèlent $k."
            p.contains("entourage") -> "Autour de vous, je sens $k."
            p.contains("obstacle") || p.contains("freine") -> "Sur votre chemin, une épreuve se dresse : $k."
            p.contains("défi") -> "Le défi que les cartes vous posent : $k."
            p.contains("racines") -> "Aux racines de cette situation, il y a $k."
            p.contains("objectif") -> "Ce que vous cherchez à atteindre : $k."
            p.contains("espoirs") -> "Au fond de vous, entre espoirs et peurs : $k."
            p.contains("résultat") || p.contains("issue") -> "Et au bout du chemin, les cartes dévoilent $k."
            p.contains("s'en va") -> "Ce qui s'éloigne : $k."
            p.contains("arrive") -> "Ce qui vient vers vous : $k."
            p.contains("guide") -> "Ce qui vous guide : $k."
            p.contains("soutient") || p.contains("aide") -> "Ce qui vous protège et vous soutient : $k."
            p.contains("cœur") || p.contains("situation") -> "Au cœur de votre situation, je vois $k."
            else -> "$pos : $k."
        }
    }

    /** L'ambiance générale : couleurs dominantes et poids des arcanes majeurs. */
    private fun ambiance(picks: List<Carte>): String {
        val n = picks.size
        val parts = ArrayList<String>()

        val counts = THEMES.map { s -> s.first to picks.count { themeOf(it) == s.first } }
            .filter { it.second > 0 }
        val max = counts.maxOfOrNull { it.second } ?: 0
        val tops = counts.filter { it.second == max }.map { t -> THEMES.first { it.first == t.first }.second }
        if (max >= 2 || (n == 1 && max == 1)) {
            parts.add(
                when (tops.size) {
                    1 -> "Ce que je vois d'abord dans votre tirage, c'est ${tops[0]}."
                    2 -> "Les cartes parlent à la fois de ${tops[0]} et de ${tops[1]}."
                    else -> "Les cartes touchent plusieurs domaines de votre vie à parts égales."
                }
            )
        } else if (n > 1) {
            parts.add("Les cartes touchent des domaines variés de votre vie : aucun ne prend le dessus.")
        }

        val fond = picks.count { isFondatrice(it) }
        if (fond > 0) {
            parts.add(if (n == 1) "C'est une carte fondatrice : un message de fond, qui touche à votre destinée." else "Une carte fondatrice est sortie : un message de fond, qui touche à votre destinée.")
        }
        val maj = picks.count { isMajeur(it) }
        if (!picks.any { estOracle(it) }) parts.add(
            when {
                n == 1 && maj == 1 -> "C'est un arcane majeur : un message d'importance, à ne pas prendre à la légère."
                n == 1 -> "C'est un arcane mineur : il parle de votre quotidien, de ce que vous vivez jour après jour."
                maj == 0 -> "Aucun arcane majeur n'est sorti : vous êtes dans le quotidien, et vous avez prise sur ce qui arrive."
                maj * 2 >= n -> "Beaucoup d'arcanes majeurs : le destin parle fort. C'est un moment qui compte dans votre vie."
                maj == 1 -> "Un seul arcane majeur : un événement marquant se détache dans votre situation."
                else -> "$maj arcanes majeurs : certains moments de votre situation sont décisifs, le destin y est à l'œuvre."
            }
        )
        return parts.joinToString(" ")
    }

    /** Accords (addition) et tensions (combat) entre les cartes qui se font face. */
    private fun liens(tirage: Tirage, picks: List<Carte>): String {
        if (tirage.duos.isEmpty() && tirage.groupes.isEmpty() && tirage.pivot < 0) return ""
        val lignes = ArrayList<String>()
        for ((a, b) in tirage.duos) {
            if (a >= picks.size || b >= picks.size) continue
            val ca = picks[a]
            val cb = picks[b]
            val fa = themeOf(ca) ?: continue
            val fb = themeOf(cb) ?: continue
            val duo = "${ca.nom} (${tirage.positions[a]}) et ${cb.nom} (${tirage.positions[b]})"
            if (fa == fb) {
                val echo = pantheon(ca) != pantheon(cb)
                lignes.add(
                    if (echo) "$duo disent la même chose dans deux traditions différentes : ${phraseTheme(fa)}. Leurs forces s'additionnent : c'est une loi qu'on ne peut pas contourner."
                    else "$duo parlent de la même chose : ${phraseTheme(fa)}. Leurs forces s'additionnent."
                )
            } else if (enTension(fa, fb)) {
                lignes.add("${ca.nom} (${tirage.positions[a]}) fait face à ${cb.nom} (${tirage.positions[b]}) : ${fa.lowercase()} contre ${fb.lowercase()}. L'une vient mettre l'autre à l'épreuve, et il faut trouver la juste voie entre les deux.")
            }
        }
        for ((nom, idxs) in tirage.groupes) {
            val fams = idxs.filter { it < picks.size }.mapNotNull { themeOf(picks[it]) }
            val rep = fams.groupingBy { it }.eachCount().filter { it.value >= 2 }
            for ((f, n) in rep) {
                lignes.add("Dans $nom, ${phraseTheme(f)} revient $n fois : c'est un bloc de force qui pèse sur toute la ligne.")
            }
        }
        if (tirage.pivot in picks.indices) {
            val pv = picks[tirage.pivot]
            lignes.add("La carte pivot, ${pv.nom}, fait pencher la balance : ${mots(pv)}.")
        }
        if (tirage.duos.isNotEmpty() && lignes.none { !it.startsWith("La carte pivot") }) {
            lignes.add(0, "Aucun duo ne s'accorde ni ne s'oppose franchement : chaque carte éclaire un aspect différent de votre situation.")
        }
        val sb = StringBuilder("<p><b><font color='$GOLD'>Accords et tensions</font></b>")
        for (l in lignes) sb.append("<br>• $l")
        sb.append("</p>")
        return sb.toString()
    }

    /** Renvoie le résumé en HTML (pour Html.fromHtml). */
    fun html(tirage: Tirage, picks: List<Carte>): String {
        val sb = StringBuilder()
        val n = picks.size

        sb.append("<p><b><font color='$GOLD'>En résumé</font></b><br>${ambiance(picks)}</p>")

        if (n > 1) {
            sb.append("<p><b><font color='$GOLD'>L'histoire que racontent vos cartes</font></b>")
            picks.forEachIndexed { i, c ->
                sb.append("<br>• ${phrase(tirage.positions[i], c)}")
            }
            sb.append("</p>")
        } else {
            sb.append("<p>${phrase(tirage.positions[0], picks[0])}</p>")
        }

        sb.append(liens(tirage, picks))
        sb.append(conseil(tirage, picks))
        return sb.toString()
    }

    private val CONSEIL_COULEUR = mapOf(
        "Bâtons" to "Le feu est en vous : il est temps d'agir. Choisissez une priorité, un projet qui vous tient à cœur, et avancez pas à pas. Votre énergie est votre meilleure alliée, à condition de ne pas l'éparpiller.",
        "Coupes" to "Votre cœur sait déjà beaucoup de choses : écoutez-le. Osez dire ce que vous ressentez aux personnes qui comptent pour vous, et prenez soin de vos liens avant de trancher.",
        "Épées" to "Gardez l'esprit clair. Prenez le temps de réfléchir, puis dites les choses franchement, sans détour. Ne décidez jamais sous le coup de la colère ou de l'inquiétude : la lucidité est votre meilleure arme.",
        "Deniers" to "Gardez les pieds sur terre : regardez votre travail, vos finances, votre sécurité. Construisez pas à pas, sur du solide. La patience et la régularité finiront par vous récompenser.",
        "Soleil" to "La lumière est de votre côté : osez vous montrer, célébrez ce que vous avez accompli et entourez-vous de ceux qui vous veulent du bien.",
        "Lune" to "Fiez-vous à votre intuition et à vos émotions, mais laissez à chaque chose le temps de se dévoiler. Ne tranchez pas avant d'y voir clair.",
        "Mars" to "L'énergie est vive, parfois conflictuelle : gardez votre calme, choisissez vos batailles et évitez les paroles qui blessent. Votre courage est une force si vous la dirigez bien.",
        "Mercure" to "Les échanges comptent : informez-vous, vérifiez les chiffres et les nouvelles, puis décidez avec discernement. Restez vigilant sur l'argent et les papiers.",
        "Jupiter" to "La chance vous sourit et vos appuis sont solides : avancez avec confiance, remerciez ceux qui vous soutiennent et ne craignez pas de demander de l'aide.",
        "Vénus" to "Prenez soin de vos liens et de vos plaisirs : dites ce que vous ressentez et offrez du temps à ceux que vous aimez.",
        "Saturne" to "Armez-vous de patience : les retards et les épreuves ne durent pas, et ils vous apprennent l'essentiel. Avancez à votre pas, sans rien précipiter.",
        "Ciel" to "Prenez de la hauteur : regardez votre situation dans son ensemble avant de trancher. L'ordre et la vision à long terme sont vos meilleurs alliés.",
        "Tempête" to "Un grand mouvement est en route : ne vous accrochez pas à ce qui doit partir. Gardez votre souffle et choisissez la direction où vous laissez le vent vous porter.",
        "Sagesse" to "Fiez-vous à l'intuition et à la réflexion profonde. Écoutez ce qui ne se voit pas encore avant de décider.",
        "Passion" to "Votre énergie est vive : mettez-la au service de ce qui vous tient vraiment à cœur, sans la laisser vous consumer.",
        "Quête" to "Gardez le cap : ce chemin demande de la persévérance et du courage. Avancez une étape à la fois, sans renoncer.",
        "Lumière" to "Cherchez la clarté : dites ce qui est vrai, soyez juste et laissez la lumière guider votre prochain pas.",
        "Ombre" to "Un temps de retrait et d'introspection vous est demandé. Regardez ce que vous évitez : c'est là que se trouve ce qui doit être transformé.",
        "Joie" to "Accordez-vous la fête et l'abondance : la joie n'est pas un luxe, c'est une force. Partagez ce que vous avez reçu.",
        "Terre" to "Revenez à l'essentiel : le concret, le soin des autres, les gestes simples qui nourrissent. Construisez lentement, sur du solide.",
        "Création" to "Le moment est à la création : posez une première pierre, réparez ce qui peut l'être et osez recommencer sur de meilleures bases.",
        "Protection" to "Posez vos limites et restez vigilant : se protéger n'est pas se fermer. Défendez avec fermeté ce qui compte pour vous."
    )

    /** Le conseil, développé en plusieurs paragraphes harmonieux. */
    private fun conseil(tirage: Tirage, picks: List<Carte>): String {
        val n = picks.size
        val sb = StringBuilder()
        sb.append("<p><b><font color='$GOLD'>Le conseil des cartes</font></b></p>")

        // 1. Ouverture : le fil conducteur du tirage
        val counts = THEMES.map { s -> s.first to picks.count { themeOf(it) == s.first } }.filter { it.second > 0 }
        val max = counts.maxOfOrNull { it.second } ?: 0
        val tops = counts.filter { it.second == max }.map { it.first }
        val themes = tops.map { t -> THEMES.first { it.first == t }.second }
        val maj = picks.count { isMajeur(it) }
        val ouverture = when {
            n == 1 -> "Cette carte n'est pas venue à vous par hasard. Elle éclaire ce que vous traversez et vous indique la direction à suivre."
            themes.size == 1 -> "Les cartes sont claires : c'est sur ${themes[0]} que vous devez porter votre attention. C'est là que tout se joue pour vous en ce moment, et c'est là que vous avez le plus à gagner."
            maj * 2 >= n -> "Vos cartes dessinent un moment important de votre vie. Rien n'est dû au hasard dans ce tirage : elles vous demandent de prendre ce qui arrive au sérieux, avec calme et confiance."
            else -> "Vos cartes forment un tout : elles vous montrent d'où vous venez, où vous en êtes et ce qui vous attend, afin d'éclairer votre prochain pas."
        }
        sb.append("<p>$ouverture</p>")

        // 2. Les conseils des cartes clés, enchaînés
        val mid = picks.indices.firstOrNull {
            val p = tirage.positions[it].lowercase()
            n > 2 && it != n - 1 && (p.contains("présent") || p.contains("guide") || p == "vous" || p.contains("cœur"))
        } ?: (n / 2)
        val vig = picks.indices.firstOrNull {
            val p = tirage.positions[it].lowercase()
            n > 1 && it != n - 1 && (p.contains("obstacle") || p.contains("freine") || p.contains("défi") || p.contains("peurs"))
        }
        val chosen = ArrayList<Int>()
        for (i in listOfNotNull(mid, vig, 0)) if (i != n - 1 && i !in chosen && chosen.size < 2) chosen.add(i)
        chosen.sort()
        if (n > 1) chosen.add(n - 1) else chosen.add(0)
        val liens = if (chosen.size == 1) listOf("Voici ce que les cartes vous disent :")
        else if (chosen.size == 2) listOf("Écoutez bien ceci :", "Et pour aller au bout :")
        else listOf("Écoutez bien ceci :", "Ensuite, n'oubliez pas :", "Enfin, pour aller au bout :")
        val conseils = StringBuilder()
        chosen.forEachIndexed { k, idx ->
            val c = picks[idx]
            val pre = if (idx == vig) "Prenez garde à ce point (${tirage.positions[idx]}) :" else liens[k]
            if (k > 0) conseils.append("<br>")
            conseils.append("$pre ${c.c}")
        }
        sb.append("<p>$conseils</p>")

        // 3. Ce que cela veut dire concrètement dans la vie
        val concret = ArrayList<String>()
        if (tops.isNotEmpty() && (themes.size <= 2)) tops.forEach { t -> CONSEIL_COULEUR[t]?.let { concret.add(it) } }
        if (n > 1 && maj * 2 >= n) concret.add("Revenez sur ce tirage dans quelques jours : certaines cartes livreront tout leur sens à mesure que les événements se préciseront.")
        if (concret.isEmpty()) concret.add("Faites confiance au mouvement de la vie : avancez avec douceur, à votre rythme, et restez à l'écoute des signes qui se présenteront.")
        sb.append("<p>${concret.joinToString(" ")}</p>")

        // 4. Fermeture
        sb.append("<p><i>Voilà ce que les cartes avaient à vous dire. Elles éclairent le chemin, mais c'est vous qui décidez de le suivre. Avancez avec confiance, et que cette lecture vous accompagne.</i></p>")
        return sb.toString()
    }
}
