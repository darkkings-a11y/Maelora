package com.maelora.arcanes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.util.Random

// Carré de présentation d'un jeu. Si assets/jaquettes/<id>.jpg (ou .png) existe, il s'affiche ;
// sinon un carré provisoire est dessiné.
class JaquetteView(ctx: Context, private val deck: Deck) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var bmp: Bitmap? = null
    private var cherche = false

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, w)
    }

    private fun charger(): Bitmap? {
        if (!cherche) {
            cherche = true
            for (ext in listOf("jpg", "png")) {
                try {
                    context.assets.open("jaquettes/" + deck.id + "." + ext).use { bmp = BitmapFactory.decodeStream(it) }
                    if (bmp != null) break
                } catch (e: Exception) {
                    bmp = null
                }
            }
        }
        return bmp
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rad = w * 0.08f
        val b = charger()
        if (b != null) {
            val clip = Path()
            clip.addRoundRect(RectF(0f, 0f, w, h), rad, rad, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            val s = minOf(b.width, b.height)
            val src = Rect((b.width - s) / 2, (b.height - s) / 2, (b.width + s) / 2, (b.height + s) / 2)
            c.drawBitmap(b, src, RectF(0f, 0f, w, h), p)
            c.restore()
        } else {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, 0f, w, h, Color.parseColor("#2A1A5E"), Color.parseColor("#0C0A1D"), Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, w, h, rad, rad, p)
            p.shader = null
            val r = Random(deck.id.hashCode().toLong())
            for (i in 0 until 25) {
                p.color = Color.argb(90 + r.nextInt(165), 244, 228, 176)
                c.drawCircle(w * (0.08f + r.nextFloat() * 0.84f), h * (0.08f + r.nextFloat() * 0.84f), w * (0.004f + r.nextFloat() * 0.01f), p)
            }
            val cx = w / 2
            val cy = h * 0.4f
            p.style = Paint.Style.STROKE
            p.color = Pal.gold
            p.strokeWidth = w * 0.006f
            c.drawCircle(cx, cy, w * 0.24f, p)
            c.drawCircle(cx, cy, w * 0.18f, p)
            val a = Path()
            a.addCircle(cx, cy, w * 0.14f, Path.Direction.CW)
            val m = Path()
            m.addCircle(cx + w * 0.055f, cy - w * 0.012f, w * 0.115f, Path.Direction.CW)
            a.op(m, Path.Op.DIFFERENCE)
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#F3E2A6")
            c.drawPath(a, p)
            p.typeface = Typeface.SERIF
            p.textAlign = Paint.Align.CENTER
            p.color = Pal.creme
            p.textSize = w * 0.075f
            c.drawText(deck.nom.substringBefore(' '), cx, h * 0.78f, p)
            val l2 = deck.nom.substringAfter(' ')
            var ts = w * 0.095f
            p.textSize = ts
            while (p.measureText(l2) > w * 0.86f) {
                ts -= 1f
                p.textSize = ts
            }
            c.drawText(l2, cx, h * 0.78f + w * 0.11f, p)
        }
        p.style = Paint.Style.STROKE
        p.color = Pal.gold
        p.strokeWidth = w * 0.012f
        c.drawRoundRect(w * 0.006f, w * 0.006f, w - w * 0.006f, h - w * 0.006f, rad, rad, p)
    }
}
