package com.maelora.arcanes

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class HomeActivity : Activity() {
    private fun dp(v: Int): Int = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.addView(BackgroundView(this, 0), ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(14), dp(56), dp(14), dp(32))
        col.addView(Ui.txt(this, "Maelora", 42f, Pal.creme, true))
        val sub = Ui.txt(this, "Choisissez votre jeu de cartes", 17f, Pal.creme, false)
        sub.setPadding(0, dp(8), 0, dp(24))
        col.addView(sub)
        for (r in 0 until (DECKS.size + 1) / 2) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val idx = r * 2 + k
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(8), dp(8), dp(8), dp(8))
                if (idx < DECKS.size) {
                    val deck = DECKS[idx]
                    val tuile = JaquetteView(this, deck)
                    tuile.contentDescription = deck.nom
                    tuile.setOnClickListener {
                        startActivity(Intent(this, DeckActivity::class.java).putExtra("deck", idx))
                    }
                    row.addView(tuile, lp)
                } else {
                    row.addView(View(this), lp)
                }
            }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        scroll.addView(col)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }
}
