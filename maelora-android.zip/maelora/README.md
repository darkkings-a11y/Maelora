# Maelora
Application de tirage de cartes (Android, Kotlin, sans dépendance externe). Le workflow `build.yml` la détecte via `settings.gradle.kts` et produit l'APK debug.
- Accueil : 4 carrés (Marseille, Lenormand, Belline, Rider-Waite-Smith) — jaquettes dans `assets/jaquettes/`
- Chaque jeu propose ses tirages (`Decks.kt`), puis le tirage et la page de chaque carte
- `assets/cartes/` : les 74 cartes du tarot de Marseille ; `Data.kt` : leurs textes
- `Resume.kt` : résumé clair du tirage (ambiance, histoire, conseil), affiché avant le détail carte par carte
