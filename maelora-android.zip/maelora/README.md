# Maelora — tirage des arcanes (Android)
Projet Gradle + Kotlin, sans dépendance externe. Le workflow `build.yml` le détecte via `settings.gradle.kts` et produit l'APK debug.
- `Data.kt` : les 22 arcanes majeurs (textes modifiables)
- `BackgroundView.kt` : 5 fonds spirituels dessinés en code, un différent à chaque tirage
- `CardView.kt` : design des cartes
- `MainActivity.kt` : tirage + encart d'explication ; `CardActivity.kt` : page détail d'une carte
