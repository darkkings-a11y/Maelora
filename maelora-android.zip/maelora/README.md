# Maelora — tirage des 74 cartes du tarot de Marseille (Android)
Projet Gradle + Kotlin, sans dépendance externe. Le workflow `build.yml` le détecte via `settings.gradle.kts` et produit l'APK debug.
- `app/src/main/assets/cartes/` : tes cartes (major_00..21, baton_/coupe_/denier_/epee_ 01..13)
- `Data.kt` : noms, mots-clés, descriptions et conseils de chaque carte
- `BackgroundView.kt` : 5 fonds spirituels, un différent à chaque tirage
- `MainActivity.kt` : tirage + encart d'explication ; `CardActivity.kt` : page détail d'une carte
