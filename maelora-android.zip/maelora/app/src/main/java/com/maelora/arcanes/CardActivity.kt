package com.maelora.arcanes

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class CardActivity : Activity() {
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val n = intent.getIntExtra("n", 0).coerceIn(0, CARTES.size - 1)
        val c = CARTES[n]
        val root = FrameLayout(this)
        root.addView(BackgroundView(this, n % 5), ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(16), dp(48), dp(16), dp(32))

        val cv = CardView(this, c)
        cv.faceUp = true
        val cardW = (resources.displayMetrics.widthPixels * 0.62f).toInt()
        col.addView(cv, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(18), dp(16), dp(18), dp(16))
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#E00C0A1D"))
        g.cornerRadius = dp(18).toFloat()
        g.setStroke(dp(1), Pal.gold)
        panel.background = g

        val titre = TextView(this)
        titre.text = "${ROM[n]} · ${c.nom}"
        titre.textSize = 24f
        titre.setTextColor(Pal.gold)
        titre.setTypeface(Typeface.SERIF, Typeface.BOLD)
        panel.addView(titre)

        val corps = TextView(this)
        corps.setTextColor(Pal.creme)
        corps.textSize = 17f
        corps.setTypeface(Typeface.SERIF, Typeface.NORMAL)
        corps.setLineSpacing(0f, 1.25f)
        corps.setPadding(0, dp(10), 0, 0)
        corps.text = Html.fromHtml(
            "<p><b>Mots-clés :</b> ${c.m}.</p><p>${c.d}</p><p><b>Conseil :</b> ${c.c}</p>",
            Html.FROM_HTML_MODE_LEGACY
        )
        panel.addView(corps)
        val lpPanel = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpPanel.topMargin = dp(20)
        col.addView(panel, lpPanel)

        val back = Button(this)
        back.text = "Retour au tirage"
        back.isAllCaps = false
        back.setTextColor(Pal.nuit)
        val gb = GradientDrawable()
        gb.setColor(Pal.gold)
        gb.cornerRadius = dp(28).toFloat()
        back.background = gb
        back.setPadding(dp(32), dp(10), dp(32), dp(10))
        back.setOnClickListener { finish() }
        val lpBack = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpBack.topMargin = dp(20)
        col.addView(back, lpBack)

        scroll.addView(col)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }
}
