package com.maelora.arcanes

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class TirageActivity : Activity() {
    private lateinit var deck: Deck
    private lateinit var tirage: Tirage
    private lateinit var bg: BackgroundView
    private lateinit var scroll: ScrollView
    private lateinit var slots: LinearLayout
    private lateinit var encart: LinearLayout
    private lateinit var resumeTxt: TextView
    private lateinit var detailTitre: TextView
    private lateinit var lectureTxt: TextView
    private lateinit var note: TextView
    private var theme = -1
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        deck = DECKS[intent.getIntExtra("deck", 0).coerceIn(0, DECKS.size - 1)]
        tirage = deck.tirages[intent.getIntExtra("tirage", 0).coerceIn(0, deck.tirages.size - 1)]
        val root = FrameLayout(this)
        bg = BackgroundView(this, 0)
        root.addView(bg, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(14), dp(48), dp(14), dp(32))
        col.addView(Ui.brand(this))
        col.addView(Ui.txt(this, deck.nom, 26f, Pal.creme, true))
        val sub = Ui.txt(this, tirage.nom + " — respirez, pensez à votre question, puis tirez.", 16f, Pal.creme, false)
        sub.setPadding(0, dp(8), 0, dp(16))
        col.addView(sub)
        val btn = Button(this)
        btn.text = "Tirer les cartes"
        btn.textSize = 17f
        btn.isAllCaps = false
        btn.setTextColor(Pal.nuit)
        btn.background = Ui.rond(this, Pal.gold, 28, false)
        btn.setPadding(dp(32), dp(10), dp(32), dp(10))
        btn.setOnClickListener { tirer() }
        col.addView(btn)
        note = Ui.txt(this, "Les cartes de ce jeu arrivent bientôt.", 16f, Pal.gold, false)
        note.visibility = View.GONE
        note.setPadding(0, dp(16), 0, 0)
        col.addView(note)
        slots = LinearLayout(this)
        slots.orientation = LinearLayout.VERTICAL
        slots.setPadding(0, dp(16), 0, dp(16))
        col.addView(slots, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        encart = LinearLayout(this)
        encart.orientation = LinearLayout.VERTICAL
        encart.visibility = View.GONE
        encart.setPadding(dp(18), dp(16), dp(18), dp(16))
        encart.background = Ui.rond(this, Color.parseColor("#E00C0A1D"), 18, true)
        val titre = Ui.txt(this, "Ce que dit votre tirage", 20f, Pal.gold, true)
        titre.gravity = Gravity.START
        encart.addView(titre)
        resumeTxt = Ui.txt(this, "", 16f, Pal.creme, false)
        resumeTxt.gravity = Gravity.START
        resumeTxt.setLineSpacing(0f, 1.2f)
        resumeTxt.setPadding(0, dp(8), 0, 0)
        encart.addView(resumeTxt)
        detailTitre = Ui.txt(this, "Carte par carte", 20f, Pal.gold, true)
        detailTitre.gravity = Gravity.START
        detailTitre.setPadding(0, dp(12), 0, 0)
        encart.addView(detailTitre)
        lectureTxt = Ui.txt(this, "", 16f, Pal.creme, false)
        lectureTxt.gravity = Gravity.START
        lectureTxt.setLineSpacing(0f, 1.2f)
        lectureTxt.setPadding(0, dp(8), 0, 0)
        encart.addView(lectureTxt)
        col.addView(encart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.addView(col)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private fun tirer() {
        handler.removeCallbacksAndMessages(null)
        slots.removeAllViews()
        encart.visibility = View.GONE
        if (deck.cartes.isEmpty()) {
            note.visibility = View.VISIBLE
            return
        }
        note.visibility = View.GONE
        val n = tirage.positions.size
        val picks = deck.cartes.shuffled().take(n)
        var t = (0 until 5).random()
        while (t == theme) t = (0 until 5).random()
        theme = t
        bg.setTheme(t)
        val cols = 3
        var i = 0
        while (i < picks.size) {
            val k = minOf(cols, picks.size - i)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val pad = (cols - k) / 2f
            if (pad > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, 1, pad))
            for (j in 0 until k) {
                val idx = i + j
                val c = picks[idx]
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                val label = Ui.txt(this, tirage.positions[idx], 14f, Pal.gold, false)
                label.setTypeface(Typeface.SERIF, Typeface.ITALIC)
                cell.addView(label)
                val cv = CardView(this, c)
                cell.addView(cv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                val nm = Ui.txt(this, "", 13f, Pal.creme, true)
                nm.setPadding(0, dp(4), 0, 0)
                cell.addView(nm)
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(4), 0, dp(4), 0)
                row.addView(cell, lp)
                cv.reveler(400L + idx * 600L) {
                    nm.text = c.nom
                    cv.setOnClickListener {
                        startActivity(
                            Intent(this, CardActivity::class.java)
                                .putExtra("deck", DECKS.indexOf(deck))
                                .putExtra("n", deck.cartes.indexOf(c))
                        )
                    }
                }
            }
            if (pad > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, 1, pad))
            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rlp.topMargin = dp(10)
            slots.addView(row, rlp)
            i += k
        }
        handler.postDelayed({ lecture(picks) }, 400L + n * 600L + 600L)
    }

    private fun lecture(picks: List<Carte>) {
        val sb = StringBuilder()
        picks.forEachIndexed { i, c ->
            sb.append("<p><b><font color='#D9B45A'>${tirage.positions[i]} — ${c.nom}.</font></b> Cette carte parle de ${c.m}. ${c.c}</p>")
        }
        sb.append("<p><i>Lisez les cartes comme une histoire, de la première à la dernière. Touchez une carte pour lire sa signification complète.</i></p>")
        resumeTxt.text = Html.fromHtml(Resume.html(tirage, picks), Html.FROM_HTML_MODE_LEGACY)
        lectureTxt.text = Html.fromHtml(sb.toString(), Html.FROM_HTML_MODE_LEGACY)
        encart.visibility = View.VISIBLE
        scroll.post { scroll.smoothScrollTo(0, encart.top) }
    }
}
