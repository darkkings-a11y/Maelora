package com.maelora.arcanes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import java.util.Random

class CardView(ctx: Context, private val carte: Carte) : View(ctx) {
    var faceUp = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var bmp: Bitmap? = null
    private val dst = RectF()

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w * 1.339f).toInt())
    }

    fun reveler(delay: Long, fin: () -> Unit) {
        animate().setStartDelay(delay).setDuration(250).scaleX(0f).withEndAction {
            faceUp = true
            invalidate()
            animate().setStartDelay(0).setDuration(250).scaleX(1f).withEndAction { fin() }.start()
        }.start()
    }

    private fun charger(): Bitmap? {
        if (bmp == null) {
            try {
                context.assets.open("cartes/" + carte.img).use { bmp = BitmapFactory.decodeStream(it) }
            } catch (e: Exception) {
                bmp = null
            }
        }
        return bmp
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val b = if (faceUp) charger() else null
        if (b != null) {
            dst.set(0f, 0f, w, h)
            c.drawBitmap(b, null, dst, p)
        } else {
            back(c, w, h)
        }
    }

    private fun back(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#1B1448"), Color.parseColor("#0C0A1D"), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, w * 0.07f, w * 0.07f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.color = Pal.gold
        p.strokeWidth = w * 0.012f
        c.drawRoundRect(w * 0.04f, w * 0.04f, w - w * 0.04f, h - w * 0.04f, w * 0.05f, w * 0.05f, p)
        val r = Random(99L)
        p.style = Paint.Style.FILL
        for (i in 0 until 14) {
            p.color = Color.argb(100 + r.nextInt(155), 244, 228, 176)
            c.drawCircle(w * (0.1f + r.nextFloat() * 0.8f), h * (0.1f + r.nextFloat() * 0.8f), w * (0.004f + r.nextFloat() * 0.008f), p)
        }
        val cx = w / 2
        val cy = h / 2
        p.style = Paint.Style.STROKE
        p.color = Pal.gold
        p.strokeWidth = w * 0.006f
        c.drawCircle(cx, cy, w * 0.3f, p)
        c.drawCircle(cx, cy, w * 0.22f, p)
        val a = Path()
        a.addCircle(cx, cy, w * 0.18f, Path.Direction.CW)
        val b = Path()
        b.addCircle(cx + w * 0.07f, cy - w * 0.015f, w * 0.15f, Path.Direction.CW)
        a.op(b, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = Color.argb(230, 243, 226, 166)
        c.drawPath(a, p)
    }
}
