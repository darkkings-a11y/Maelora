package com.maelora.arcanes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class CardView(ctx: Context, private val carte: Carte) : View(ctx) {
    var faceUp = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w * 1.7f).toInt())
    }

    fun reveler(delay: Long, fin: () -> Unit) {
        animate().setStartDelay(delay).setDuration(250).scaleX(0f).withEndAction {
            faceUp = true
            invalidate()
            animate().setStartDelay(0).setDuration(250).scaleX(1f).withEndAction { fin() }.start()
        }.start()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (faceUp) face(c, w, h) else back(c, w, h)
    }

    private fun frame(c: Canvas, w: Float, h: Float, top: Int, bot: Int) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, top, bot, Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, w * 0.07f, w * 0.07f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.color = Pal.gold
        p.strokeWidth = w * 0.012f
        c.drawRoundRect(w * 0.04f, w * 0.04f, w - w * 0.04f, h - w * 0.04f, w * 0.05f, w * 0.05f, p)
        p.strokeWidth = w * 0.004f
        c.drawRoundRect(w * 0.07f, w * 0.07f, w - w * 0.07f, h - w * 0.07f, w * 0.03f, w * 0.03f, p)
    }

    private fun crescent(c: Canvas, cx: Float, cy: Float, rad: Float, alpha: Int) {
        val a = Path()
        a.addCircle(cx, cy, rad, Path.Direction.CW)
        val b = Path()
        b.addCircle(cx + rad * 0.4f, cy - rad * 0.08f, rad * 0.82f, Path.Direction.CW)
        a.op(b, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = Color.argb(alpha, 243, 226, 166)
        c.drawPath(a, p)
    }

    private fun stars(c: Canvas, w: Float, h: Float, seed: Long, n: Int) {
        val r = Random(seed)
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            p.color = Color.argb(100 + r.nextInt(155), 244, 228, 176)
            c.drawCircle(w * (0.1f + r.nextFloat() * 0.8f), h * (0.1f + r.nextFloat() * 0.8f), w * (0.004f + r.nextFloat() * 0.008f), p)
        }
    }

    private fun back(c: Canvas, w: Float, h: Float) {
        frame(c, w, h, Color.parseColor("#1B1448"), Color.parseColor("#0C0A1D"))
        stars(c, w, h, 99L, 14)
        val cx = w / 2
        val cy = h / 2
        p.style = Paint.Style.STROKE
        p.color = Pal.gold
        p.strokeWidth = w * 0.006f
        c.drawCircle(cx, cy, w * 0.3f, p)
        c.drawCircle(cx, cy, w * 0.22f, p)
        crescent(c, cx, cy, w * 0.18f, 230)
    }

    private fun face(c: Canvas, w: Float, h: Float) {
        val n = carte.n
        val hue = ((n * 37 + 220) % 360).toFloat()
        val top = Color.HSVToColor(floatArrayOf(hue, 0.6f, 0.3f))
        val bot = Color.HSVToColor(floatArrayOf((hue + 50f) % 360f, 0.65f, 0.12f))
        frame(c, w, h, top, bot)
        stars(c, w, h, n + 3L, 22)
        val cx = w / 2
        val cy = h * 0.47f
        val rad = w * 0.36f
        p.style = Paint.Style.STROKE
        p.color = Pal.gold
        p.strokeWidth = w * 0.006f
        c.drawCircle(cx, cy, rad, p)
        c.drawCircle(cx, cy, rad * 0.82f, p)
        val pts = 5 + n % 7
        val path = Path()
        for (i in 0..pts) {
            val idx = (i * 2) % pts
            val a = -PI / 2 + 2 * PI * idx / pts
            val x = cx + rad * 0.82f * cos(a).toFloat()
            val y = cy + rad * 0.82f * sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, p)
        p.color = Color.argb(90, 217, 180, 90)
        for (i in 0 until pts) {
            val a = -PI / 2 + 2 * PI * i / pts
            c.drawLine(cx, cy, cx + rad * 0.82f * cos(a).toFloat(), cy + rad * 0.82f * sin(a).toFloat(), p)
        }
        crescent(c, cx, cy, rad * 0.5f, 210)
        p.style = Paint.Style.FILL
        p.shader = null
        p.typeface = Typeface.SERIF
        p.textAlign = Paint.Align.CENTER
        p.color = Pal.gold
        p.textSize = w * 0.1f
        c.drawText(ROM[n], cx, h * 0.095f, p)
        p.color = Pal.creme
        var ts = w * 0.09f
        p.textSize = ts
        while (p.measureText(carte.nom) > w * 0.84f) {
            ts -= 1f
            p.textSize = ts
        }
        c.drawText(carte.nom, cx, h * 0.93f, p)
    }
}
