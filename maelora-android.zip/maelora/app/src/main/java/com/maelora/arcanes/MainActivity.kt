package com.maelora.arcanes

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var bg: BackgroundView
    private lateinit var scroll: ScrollView
    private lateinit var slots: LinearLayout
    private lateinit var encart: LinearLayout
    private lateinit var lectureTxt: TextView
    private var theme = -1
    private val handler = Handler(Looper.getMainLooper())
    private val pos = listOf("Passé", "Présent", "Futur")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun txt(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        tv.setTypeface(Typeface.SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        tv.gravity = Gravity.CENTER
        return tv
    }

    private fun rond(color: Int, r: Int, stroke: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke) g.setStroke(dp(1), Pal.gold)
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        bg = BackgroundView(this, 0)
        root.addView(bg, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(14), dp(48), dp(14), dp(32))
        col.addView(txt("Les Arcanes", 32f, Pal.creme, true))
        val intro = txt("Respirez, pensez à votre question, puis tirez trois cartes.", 16f, Pal.creme, false)
        intro.setPadding(0, dp(8), 0, dp(16))
        col.addView(intro)
        val btn = Button(this)
        btn.text = "Tirer les cartes"
        btn.textSize = 17f
        btn.isAllCaps = false
        btn.setTextColor(Pal.nuit)
        btn.background = rond(Pal.gold, 28, false)
        btn.setPadding(dp(32), dp(10), dp(32), dp(10))
        btn.setOnClickListener { tirer() }
        col.addView(btn)
        slots = LinearLayout(this)
        slots.orientation = LinearLayout.HORIZONTAL
        slots.setPadding(0, dp(24), 0, dp(16))
        col.addView(slots, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        encart = LinearLayout(this)
        encart.orientation = LinearLayout.VERTICAL
        encart.visibility = View.GONE
        encart.setPadding(dp(18), dp(16), dp(18), dp(16))
        encart.background = rond(Color.parseColor("#E00C0A1D"), 18, true)
        val titre = txt("Ce que dit votre tirage", 20f, Pal.gold, true)
        titre.gravity = Gravity.START
        encart.addView(titre)
        lectureTxt = txt("", 16f, Pal.creme, false)
        lectureTxt.gravity = Gravity.START
        lectureTxt.setLineSpacing(0f, 1.2f)
        lectureTxt.setPadding(0, dp(8), 0, 0)
        encart.addView(lectureTxt)
        col.addView(encart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.addView(col)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private fun tirer() {
        handler.removeCallbacksAndMessages(null)
        val picks = CARTES.shuffled().take(3)
        var t = (0 until 5).random()
        while (t == theme) t = (0 until 5).random()
        theme = t
        bg.setTheme(t)
        slots.removeAllViews()
        encart.visibility = View.GONE
        picks.forEachIndexed { i, c ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val label = txt(pos[i], 15f, Pal.gold, false)
            label.setTypeface(Typeface.SERIF, Typeface.ITALIC)
            cell.addView(label)
            val cv = CardView(this, c)
            cell.addView(cv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val nm = txt("", 14f, Pal.creme, true)
            nm.setPadding(0, dp(6), 0, 0)
            cell.addView(nm)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            slots.addView(cell, lp)
            cv.reveler(400L + i * 600L) {
                nm.text = c.nom
                cv.setOnClickListener {
                    startActivity(Intent(this, CardActivity::class.java).putExtra("n", c.n))
                }
            }
        }
        handler.postDelayed({ lecture(picks) }, 400L + 3 * 600L + 600L)
    }

    private fun lecture(picks: List<Carte>) {
        val sb = StringBuilder()
        picks.forEachIndexed { i, c ->
            sb.append("<p><b><font color='#D9B45A'>${pos[i]} — ${c.nom}.</font></b> Cette carte parle de ${c.m}. ${c.c}</p>")
        }
        sb.append("<p><i>Lisez les trois cartes comme une histoire : ce qui vous a menés ici, ce que vous vivez, ce qui s'ouvre. Touchez une carte pour lire sa signification complète.</i></p>")
        lectureTxt.text = Html.fromHtml(sb.toString(), Html.FROM_HTML_MODE_LEGACY)
        encart.visibility = View.VISIBLE
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
