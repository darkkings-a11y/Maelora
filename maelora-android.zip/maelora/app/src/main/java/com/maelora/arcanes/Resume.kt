package com.maelora.arcanes

/**
 * Génère le résumé clair d'un tirage, affiché AVANT le détail carte par carte.
 * Fonctionne pour tous les jeux et tous les tirages : il s'appuie sur la position
 * de chaque carte, ses mots-clés (Carte.m) et son conseil (Carte.c).
 */
object Resume {
    private const val GOLD = "#D9B45A"

    private val SUITS = listOf(
        "Bâtons" to "l'action, l'énergie et les projets",
        "Coupes" to "les émotions et les relations",
        "Épées" to "les pensées, la vérité et les décisions",
        "Deniers" to "le concret : le travail, l'argent et la sécurité"
    )

    private fun suitOf(c: Carte): String? = SUITS.firstOrNull { c.nom.contains(it.first) }?.first

    private fun isMajeur(c: Carte): Boolean = suitOf(c) == null

    /** Deux premiers mots-clés de la carte, reliés par « et ». */
    private fun mots(c: Carte): String {
        val k = c.m.split(", ").map { it.trim() }.filter { it.isNotEmpty() }
        return when {
            k.isEmpty() -> c.m
            k.size == 1 -> k[0]
            else -> k[0] + " et " + k[1]
        }
    }

    /** Une phrase naturelle selon la position de la carte dans le tirage. */
    private fun phrase(pos: String, c: Carte): String {
        val k = mots(c)
        val p = pos.lowercase()
        return when {
            p == "le message" -> "Le message du moment : $k."
            p == "passé" || p == "le passé" -> "Votre passé est marqué par $k."
            p == "présent" || p == "le présent" -> "Aujourd'hui, ce qui domine, c'est $k."
            p == "futur" || p == "l'avenir" -> "L'avenir s'annonce sous le signe de $k."
            p.contains("avenir proche") -> "Dans les prochains temps : $k."
            p.contains("passé récent") -> "Récemment, vous avez traversé $k."
            p == "vous" -> "En vous, on trouve $k."
            p.contains("entourage") -> "Autour de vous, on trouve $k."
            p.contains("obstacle") || p.contains("freine") -> "Ce qui peut vous freiner : $k."
            p.contains("défi") -> "Le défi à relever : $k."
            p.contains("racines") -> "Les racines de la situation : $k."
            p.contains("objectif") -> "Ce vers quoi vous tendez : $k."
            p.contains("espoirs") -> "Entre espoirs et peurs : $k."
            p.contains("résultat") || p.contains("issue") -> "Ce qui se dessine à la fin : $k."
            p.contains("s'en va") -> "Ce qui s'éloigne : $k."
            p.contains("arrive") -> "Ce qui arrive : $k."
            p.contains("guide") -> "Ce qui vous guide : $k."
            p.contains("soutient") || p.contains("aide") -> "Ce qui vous soutient : $k."
            p.contains("cœur") || p.contains("situation") -> "Au cœur de la situation : $k."
            else -> "$pos : $k."
        }
    }

    /** L'ambiance générale : couleurs dominantes et poids des arcanes majeurs. */
    private fun ambiance(picks: List<Carte>): String {
        val n = picks.size
        val parts = ArrayList<String>()

        val counts = SUITS.map { s -> s.first to picks.count { suitOf(it) == s.first } }
            .filter { it.second > 0 }
        val max = counts.maxOfOrNull { it.second } ?: 0
        val tops = counts.filter { it.second == max }.map { t -> SUITS.first { it.first == t.first }.second }
        if (max >= 2 || (n == 1 && max == 1)) {
            parts.add(
                when (tops.size) {
                    1 -> "Ce tirage parle surtout de ${tops[0]}."
                    2 -> "Ce tirage parle à la fois de ${tops[0]} et de ${tops[1]}."
                    else -> "Ce tirage touche plusieurs domaines de votre vie à parts égales."
                }
            )
        } else if (n > 1) {
            parts.add("Les cartes touchent des domaines variés de votre vie : aucun ne prend le dessus.")
        }

        val maj = picks.count { isMajeur(it) }
        parts.add(
            when {
                n == 1 && maj == 1 -> "C'est un arcane majeur : le message est important."
                n == 1 -> "C'est un arcane mineur : il parle d'une situation du quotidien."
                maj == 0 -> "Aucun arcane majeur : il s'agit de situations du quotidien, sur lesquelles vous avez prise."
                maj * 2 >= n -> "Beaucoup d'arcanes majeurs : des enjeux importants, un moment qui compte dans votre vie."
                maj == 1 -> "Un seul arcane majeur : un point marquant se détache dans votre situation."
                else -> "$maj arcanes majeurs : certains moments de votre situation sont décisifs."
            }
        )
        return parts.joinToString(" ")
    }

    /** Renvoie le résumé en HTML (pour Html.fromHtml). */
    fun html(tirage: Tirage, picks: List<Carte>): String {
        val sb = StringBuilder()
        val n = picks.size

        sb.append("<p><b><font color='$GOLD'>En résumé</font></b><br>${ambiance(picks)}</p>")

        if (n > 1) {
            sb.append("<p><b><font color='$GOLD'>L'histoire de votre tirage</font></b>")
            picks.forEachIndexed { i, c ->
                sb.append("<br>• ${phrase(tirage.positions[i], c)}")
            }
            sb.append("</p>")
        } else {
            sb.append("<p>${phrase(tirage.positions[0], picks[0])}</p>")
        }

        val last = picks.last()
        sb.append("<p><b><font color='$GOLD'>Le conseil des cartes</font></b><br>${last.c}")
        val vigilance = picks.indices.firstOrNull {
            val p = tirage.positions[it].lowercase()
            n > 1 && it != n - 1 && (p.contains("obstacle") || p.contains("freine") || p.contains("défi") || p.contains("peurs"))
        }
        if (vigilance != null) {
            sb.append("<br>À surveiller : ${picks[vigilance].c}")
        }
        sb.append("</p>")
        return sb.toString()
    }
}
