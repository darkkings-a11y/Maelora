package com.maelora.arcanes

/**
 * Génère le résumé clair d'un tirage, affiché AVANT le détail carte par carte.
 * Fonctionne pour tous les jeux et tous les tirages : il s'appuie sur la position
 * de chaque carte, ses mots-clés (Carte.m) et son conseil (Carte.c).
 */
object Resume {
    private const val GOLD = "#D9B45A"

    private val SUITS = listOf(
        "Bâtons" to "l'action, l'énergie et les projets",
        "Coupes" to "les émotions et les relations",
        "Épées" to "les pensées, la vérité et les décisions",
        "Deniers" to "le concret : le travail, l'argent et la sécurité"
    )

    private fun suitOf(c: Carte): String? = SUITS.firstOrNull { c.nom.contains(it.first) }?.first

    private fun isMajeur(c: Carte): Boolean = suitOf(c) == null

    /** Deux premiers mots-clés de la carte, reliés par « et ». */
    private fun mots(c: Carte): String {
        val k = c.m.split(", ").map { it.trim() }.filter { it.isNotEmpty() }
        return when {
            k.isEmpty() -> c.m
            k.size == 1 -> k[0]
            else -> k[0] + " et " + k[1]
        }
    }

    /** Une phrase naturelle selon la position de la carte dans le tirage. */
    private fun phrase(pos: String, c: Carte): String {
        val k = mots(c)
        val p = pos.lowercase()
        return when {
            p == "le message" -> "Le message que les cartes vous envoient : $k."
            p == "passé" || p == "le passé" -> "Dans votre passé, je vois $k."
            p == "présent" || p == "le présent" -> "En ce moment, les cartes me montrent $k."
            p == "futur" || p == "l'avenir" -> "Devant vous, je vois venir $k."
            p.contains("avenir proche") -> "Dans les prochains temps, les cartes annoncent $k."
            p.contains("passé récent") -> "Récemment, vous avez traversé $k."
            p == "vous" -> "En vous, les cartes révèlent $k."
            p.contains("entourage") -> "Autour de vous, je sens $k."
            p.contains("obstacle") || p.contains("freine") -> "Sur votre chemin, une épreuve se dresse : $k."
            p.contains("défi") -> "Le défi que les cartes vous posent : $k."
            p.contains("racines") -> "Aux racines de cette situation, il y a $k."
            p.contains("objectif") -> "Ce que vous cherchez à atteindre : $k."
            p.contains("espoirs") -> "Au fond de vous, entre espoirs et peurs : $k."
            p.contains("résultat") || p.contains("issue") -> "Et au bout du chemin, les cartes dévoilent $k."
            p.contains("s'en va") -> "Ce qui s'éloigne : $k."
            p.contains("arrive") -> "Ce qui vient vers vous : $k."
            p.contains("guide") -> "Ce qui vous guide : $k."
            p.contains("soutient") || p.contains("aide") -> "Ce qui vous protège et vous soutient : $k."
            p.contains("cœur") || p.contains("situation") -> "Au cœur de votre situation, je vois $k."
            else -> "$pos : $k."
        }
    }

    /** L'ambiance générale : couleurs dominantes et poids des arcanes majeurs. */
    private fun ambiance(picks: List<Carte>): String {
        val n = picks.size
        val parts = ArrayList<String>()

        val counts = SUITS.map { s -> s.first to picks.count { suitOf(it) == s.first } }
            .filter { it.second > 0 }
        val max = counts.maxOfOrNull { it.second } ?: 0
        val tops = counts.filter { it.second == max }.map { t -> SUITS.first { it.first == t.first }.second }
        if (max >= 2 || (n == 1 && max == 1)) {
            parts.add(
                when (tops.size) {
                    1 -> "Ce que je vois d'abord dans votre tirage, c'est ${tops[0]}."
                    2 -> "Les cartes parlent à la fois de ${tops[0]} et de ${tops[1]}."
                    else -> "Les cartes touchent plusieurs domaines de votre vie à parts égales."
                }
            )
        } else if (n > 1) {
            parts.add("Les cartes touchent des domaines variés de votre vie : aucun ne prend le dessus.")
        }

        val maj = picks.count { isMajeur(it) }
        parts.add(
            when {
                n == 1 && maj == 1 -> "C'est un arcane majeur : un message d'importance, à ne pas prendre à la légère."
                n == 1 -> "C'est un arcane mineur : il parle de votre quotidien, de ce que vous vivez jour après jour."
                maj == 0 -> "Aucun arcane majeur n'est sorti : vous êtes dans le quotidien, et vous avez prise sur ce qui arrive."
                maj * 2 >= n -> "Beaucoup d'arcanes majeurs : le destin parle fort. C'est un moment qui compte dans votre vie."
                maj == 1 -> "Un seul arcane majeur : un événement marquant se détache dans votre situation."
                else -> "$maj arcanes majeurs : certains moments de votre situation sont décisifs, le destin y est à l'œuvre."
            }
        )
        return parts.joinToString(" ")
    }

    /** Renvoie le résumé en HTML (pour Html.fromHtml). */
    fun html(tirage: Tirage, picks: List<Carte>): String {
        val sb = StringBuilder()
        val n = picks.size

        sb.append("<p><b><font color='$GOLD'>En résumé</font></b><br>${ambiance(picks)}</p>")

        if (n > 1) {
            sb.append("<p><b><font color='$GOLD'>L'histoire que racontent vos cartes</font></b>")
            picks.forEachIndexed { i, c ->
                sb.append("<br>• ${phrase(tirage.positions[i], c)}")
            }
            sb.append("</p>")
        } else {
            sb.append("<p>${phrase(tirage.positions[0], picks[0])}</p>")
        }

        sb.append(conseil(tirage, picks))
        return sb.toString()
    }

    private val CONSEIL_COULEUR = mapOf(
        "Bâtons" to "Le feu est en vous : il est temps d'agir. Choisissez une priorité, un projet qui vous tient à cœur, et avancez pas à pas. Votre énergie est votre meilleure alliée, à condition de ne pas l'éparpiller.",
        "Coupes" to "Votre cœur sait déjà beaucoup de choses : écoutez-le. Osez dire ce que vous ressentez aux personnes qui comptent pour vous, et prenez soin de vos liens avant de trancher.",
        "Épées" to "Gardez l'esprit clair. Prenez le temps de réfléchir, puis dites les choses franchement, sans détour. Ne décidez jamais sous le coup de la colère ou de l'inquiétude : la lucidité est votre meilleure arme.",
        "Deniers" to "Gardez les pieds sur terre : regardez votre travail, vos finances, votre sécurité. Construisez pas à pas, sur du solide. La patience et la régularité finiront par vous récompenser."
    )

    /** Le conseil, développé en plusieurs paragraphes harmonieux. */
    private fun conseil(tirage: Tirage, picks: List<Carte>): String {
        val n = picks.size
        val sb = StringBuilder()
        sb.append("<p><b><font color='$GOLD'>Le conseil des cartes</font></b></p>")

        // 1. Ouverture : le fil conducteur du tirage
        val counts = SUITS.map { s -> s.first to picks.count { suitOf(it) == s.first } }.filter { it.second > 0 }
        val max = counts.maxOfOrNull { it.second } ?: 0
        val tops = counts.filter { it.second == max }.map { it.first }
        val themes = tops.map { t -> SUITS.first { it.first == t }.second }
        val maj = picks.count { isMajeur(it) }
        val ouverture = when {
            n == 1 -> "Cette carte n'est pas venue à vous par hasard. Elle éclaire ce que vous traversez et vous indique la direction à suivre."
            themes.size == 1 -> "Les cartes sont claires : c'est sur ${themes[0]} que vous devez porter votre attention. C'est là que tout se joue pour vous en ce moment, et c'est là que vous avez le plus à gagner."
            maj * 2 >= n -> "Vos cartes dessinent un moment important de votre vie. Rien n'est dû au hasard dans ce tirage : elles vous demandent de prendre ce qui arrive au sérieux, avec calme et confiance."
            else -> "Vos cartes forment un tout : elles vous montrent d'où vous venez, où vous en êtes et ce qui vous attend, afin d'éclairer votre prochain pas."
        }
        sb.append("<p>$ouverture</p>")

        // 2. Les conseils des cartes clés, enchaînés
        val mid = picks.indices.firstOrNull {
            val p = tirage.positions[it].lowercase()
            n > 2 && it != n - 1 && (p.contains("présent") || p.contains("guide") || p == "vous" || p.contains("cœur"))
        } ?: (n / 2)
        val vig = picks.indices.firstOrNull {
            val p = tirage.positions[it].lowercase()
            n > 1 && it != n - 1 && (p.contains("obstacle") || p.contains("freine") || p.contains("défi") || p.contains("peurs"))
        }
        val chosen = ArrayList<Int>()
        for (i in listOfNotNull(mid, vig, 0)) if (i != n - 1 && i !in chosen && chosen.size < 2) chosen.add(i)
        chosen.sort()
        if (n > 1) chosen.add(n - 1) else chosen.add(0)
        val liens = if (chosen.size == 1) listOf("Voici ce que les cartes vous disent :")
        else if (chosen.size == 2) listOf("Écoutez bien ceci :", "Et pour aller au bout :")
        else listOf("Écoutez bien ceci :", "Ensuite, n'oubliez pas :", "Enfin, pour aller au bout :")
        val conseils = StringBuilder()
        chosen.forEachIndexed { k, idx ->
            val c = picks[idx]
            val pre = if (idx == vig) "Prenez garde à ce point (${tirage.positions[idx]}) :" else liens[k]
            if (k > 0) conseils.append("<br>")
            conseils.append("$pre ${c.c}")
        }
        sb.append("<p>$conseils</p>")

        // 3. Ce que cela veut dire concrètement dans la vie
        val concret = ArrayList<String>()
        if (tops.isNotEmpty() && (themes.size <= 2)) tops.forEach { t -> CONSEIL_COULEUR[t]?.let { concret.add(it) } }
        if (n > 1 && maj * 2 >= n) concret.add("Revenez sur ce tirage dans quelques jours : certaines cartes livreront tout leur sens à mesure que les événements se préciseront.")
        if (concret.isEmpty()) concret.add("Faites confiance au mouvement de la vie : avancez avec douceur, à votre rythme, et restez à l'écoute des signes qui se présenteront.")
        sb.append("<p>${concret.joinToString(" ")}</p>")

        // 4. Fermeture
        sb.append("<p><i>Voilà ce que les cartes avaient à vous dire. Elles éclairent le chemin, mais c'est vous qui décidez de le suivre. Avancez avec confiance, et que cette lecture vous accompagne.</i></p>")
        return sb.toString()
    }
}
