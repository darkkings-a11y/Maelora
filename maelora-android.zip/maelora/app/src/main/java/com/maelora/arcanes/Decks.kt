package com.maelora.arcanes

data class Tirage(val nom: String, val desc: String, val positions: List<String>)
data class Deck(val id: String, val nom: String, val intro: String, val cartes: List<Carte>, val tirages: List<Tirage>)

private val UNE = Tirage("Une carte", "Une réponse simple, ou le conseil du jour.", listOf("Le message"))
private val TROIS = Tirage("Passé · Présent · Futur", "Le tirage classique pour lire une situation dans le temps.", listOf("Passé", "Présent", "Futur"))
private val CROIX = Tirage(
    "La croix", "Cinq cartes pour comprendre une situation en profondeur.",
    listOf("La situation", "Ce qui s'en va", "Ce qui arrive", "Ce qui vous guide", "Ce qui vous soutient")
)
private val FER = Tirage(
    "Le fer à cheval", "Sept cartes pour un regard complet sur une question.",
    listOf("Passé", "Présent", "Avenir proche", "Vous", "Votre entourage", "Les obstacles", "Le résultat")
)
private val LIGNE5 = Tirage(
    "Cinq cartes en ligne", "Une histoire en cinq temps, du début à l'issue.",
    listOf("Le début", "Le développement", "Le cœur", "L'évolution", "L'issue")
)
private val BOX9 = Tirage(
    "Le carré de neuf", "Neuf cartes pour une vue d'ensemble de votre situation.",
    listOf("Le passé", "Le présent", "L'avenir", "Vous", "Le cœur de la question", "Votre entourage", "Ce qui vous aide", "Ce qui vous freine", "Le résultat")
)
private val CELTE = Tirage(
    "La croix celtique", "Le grand tirage en dix cartes pour une question importante.",
    listOf("Le cœur de la situation", "Le défi", "Les racines", "Le passé récent", "L'objectif", "L'avenir proche", "Vous", "Votre entourage", "Espoirs et peurs", "Le résultat")
)

val DECKS = listOf(
    Deck("marseille", "Tarot de Marseille", "Les 78 lames du tarot de Marseille.", CARTES, listOf(UNE, TROIS, CROIX, FER)),
    Deck("lenormand", "Tarot Lenormand", "Le jeu de 36 cartes de Mlle Lenormand, direct et concret.", emptyList(), listOf(UNE, TROIS, LIGNE5, BOX9)),
    Deck("belline", "Oracle de Belline", "L'oracle de Belline, ses 52 cartes pour répondre à vos questions.", emptyList(), listOf(UNE, TROIS, CROIX)),
    Deck("rws", "Tarot Rider-Waite-Smith", "Le tarot le plus connu, illustré de scènes pour chacune de ses 78 cartes.", emptyList(), listOf(UNE, TROIS, FER, CELTE))
)
