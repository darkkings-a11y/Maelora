package com.maelora.arcanes

import android.graphics.Color

data class Carte(val n: Int, val nom: String, val m: String, val d: String, val c: String)

object Pal {
    val creme = Color.parseColor("#F6E7B4")
    val gold = Color.parseColor("#D9B45A")
    val nuit = Color.parseColor("#0C0A1D")
}

val ROM = listOf("0","I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII","XIII","XIV","XV","XVI","XVII","XVIII","XIX","XX","XXI")

val CARTES = listOf(
    Carte(0, "Le Mat", "un nouveau départ, une liberté, un saut dans l'inconnu", "Le Mat marche vers l'horizon sans carte ni bagage. Il annonce un commencement, une confiance spontanée, parfois de l'insouciance. Il invite à oser, tout en regardant où l'on met les pieds.", "Faites le premier pas sans attendre d'être prêt."),
    Carte(1, "Le Bateleur", "la volonté, le talent, l'initiative", "Devant sa table, le Bateleur dispose de tous les outils. Il parle d'habileté, de ressources déjà présentes et du pouvoir d'agir. Tout devient possible dès que l'on décide de commencer.", "Utilisez ce que vous avez déjà en main."),
    Carte(2, "La Papesse", "l'intuition, le silence, le secret", "Gardienne d'un livre fermé, elle représente la connaissance intérieure. Elle conseille d'écouter son intuition, de patienter et de ne pas tout dévoiler trop tôt.", "Écoutez ce que vous savez déjà au fond de vous."),
    Carte(3, "L'Impératrice", "la créativité, l'abondance, la fécondité", "Elle incarne la création sous toutes ses formes : projet, enfant, œuvre, prospérité. Elle apporte douceur, croissance et sens du concret.", "Nourrissez ce qui est en train de naître."),
    Carte(4, "L'Empereur", "la structure, l'autorité, la stabilité", "Assis sur un trône solide, l'Empereur pose des règles et protège. Il demande de l'ordre, de la rigueur et de la responsabilité pour bâtir durablement.", "Posez un cadre clair et tenez-vous-y."),
    Carte(5, "Le Pape", "la transmission, la tradition, la guidance", "Maître spirituel, il relie le visible à l'invisible. Il évoque l'enseignement, les valeurs, un conseil précieux ou un cadre à respecter.", "Cherchez un guide ou devenez-en un."),
    Carte(6, "L'Amoureux", "un choix du cœur, une union, un alignement", "Entre deux chemins, l'Amoureux oblige à choisir selon ses vrais désirs. Il parle d'amour, d'engagement et de cohérence entre le cœur et les actes.", "Choisissez ce qui vous ressemble vraiment."),
    Carte(7, "Le Chariot", "la victoire, l'élan, la maîtrise", "Conduit par deux forces opposées, le Chariot avance quand la volonté les unit. Il promet progrès, déplacement et réussite par la détermination.", "Gardez les rênes et avancez."),
    Carte(8, "La Justice", "l'équilibre, la vérité, les conséquences", "Épée et balance en main, elle rappelle que chaque acte a un effet. Elle invite à la lucidité, à l'équité et à des décisions claires.", "Soyez juste, d'abord avec vous-même."),
    Carte(9, "L'Ermite", "le retrait, la sagesse, la quête intérieure", "Sa lanterne n'éclaire que le prochain pas. L'Ermite conseille de prendre du recul, de faire le point et de chercher la réponse en soi.", "Prenez le temps de la solitude choisie."),
    Carte(10, "La Roue de Fortune", "un cycle, un changement, le destin", "La roue tourne : rien ne dure, ni le meilleur ni le pire. Elle annonce un tournant, un coup de chance ou la fin d'une période.", "Acceptez le mouvement, il vous porte."),
    Carte(11, "La Force", "le courage, la douceur, la maîtrise de soi", "Elle dompte le lion sans violence. Cette carte parle d'une force tranquille, de patience et du courage d'affronter ses peurs.", "La douceur vient à bout de bien des obstacles."),
    Carte(12, "Le Pendu", "le lâcher-prise, une pause, un nouveau regard", "Suspendu la tête en bas, il voit le monde autrement. Il demande d'accepter l'attente, de renoncer à tout contrôler et de changer de point de vue.", "Faites une pause et regardez autrement."),
    Carte(13, "L'Arcane sans nom", "une fin, une transformation, une renaissance", "Elle ne signifie presque jamais la mort réelle. Elle marque une fin nécessaire qui libère la place du neuf : rupture, deuil symbolique, renouveau.", "Laissez partir ce qui est déjà terminé."),
    Carte(14, "Tempérance", "l'harmonie, la patience, la guérison", "Un ange mêle deux eaux sans en perdre une goutte. Tempérance parle de modération, de réconciliation et d'une énergie qui se rééquilibre.", "Avancez doucement, en mélangeant les contraires."),
    Carte(15, "Le Diable", "un attachement, une tentation, des chaînes", "Il montre ce qui nous enchaîne : dépendance, peur, désir excessif. Mais les chaînes sont lâches : la liberté est à portée de décision.", "Nommez ce qui vous retient, puis desserrez-le."),
    Carte(16, "La Maison Dieu", "une rupture, un choc, une libération", "La tour frappée par la foudre s'effondre. Un événement brutal fait tomber les illusions, douloureux mais libérateur, il ouvre la voie à plus de vérité.", "Ce qui tombe n'était pas bâti sur du solide."),
    Carte(17, "L'Étoile", "l'espoir, la guérison, la confiance", "Après la tempête, la lumière revient. L'Étoile apporte sérénité, inspiration et foi en l'avenir. C'est la carte du réconfort.", "Gardez confiance, la lumière est là."),
    Carte(18, "La Lune", "l'illusion, le rêve, l'inconscient", "Sous la lune, rien n'est tout à fait net. Elle évoque les doutes, les rêves, les peurs et les secrets. Mieux vaut attendre avant de trancher.", "Ne décidez pas dans le brouillard."),
    Carte(19, "Le Soleil", "la joie, la clarté, la réussite", "Le Soleil éclaire tout : sincérité, bonheur, vitalité, succès. C'est l'une des plus belles cartes, signe d'épanouissement.", "Profitez, montrez-vous, rayonnez."),
    Carte(20, "Le Jugement", "un éveil, un appel, une renaissance", "Une trompette réveille les dormeurs. Le Jugement annonce un bilan, un appel intérieur, un pardon et la chance de repartir autrement.", "Répondez à l'appel qui revient."),
    Carte(21, "Le Monde", "l'accomplissement, l'harmonie, l'aboutissement", "Au centre de la couronne, la danseuse est enfin entière. Le Monde célèbre un cycle bouclé, une réussite complète et l'ouverture vers l'ailleurs.", "Célébrez, puis ouvrez le prochain chapitre."),
)
