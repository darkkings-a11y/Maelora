package com.maelora.arcanes

import android.graphics.Color

// f : famille transversale de la carte (utilisée par l'oracle des anciens dieux pour les accords et les tensions).
data class Carte(val nom: String, val img: String, val m: String, val d: String, val c: String, val f: String = "")

object Pal {
    val creme = Color.parseColor("#F6E7B4")
    val gold = Color.parseColor("#D9B45A")
    val nuit = Color.parseColor("#0C0A1D")
}
