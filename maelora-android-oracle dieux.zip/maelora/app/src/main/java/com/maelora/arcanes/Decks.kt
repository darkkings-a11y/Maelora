package com.maelora.arcanes

// cols : nombre de cartes par rangée à l'écran.
// rangs : disposition à l'écran (liste de rangées d'indices de positions) ; par défaut, dans l'ordre.
// duos : paires de positions qui se font face (accord ou tension) ; pivot : position de la carte centrale ;
// groupes : lignes à lire d'un bloc (nom, positions). regle : comment lire ce tirage.
data class Tirage(
    val nom: String,
    val desc: String,
    val positions: List<String>,
    val cols: Int = 3,
    val rangs: List<List<Int>>? = null,
    val duos: List<Pair<Int, Int>> = emptyList(),
    val pivot: Int = -1,
    val groupes: List<Pair<String, List<Int>>> = emptyList(),
    val regle: String = ""
)

data class Deck(val id: String, val nom: String, val intro: String, val cartes: List<Carte>, val tirages: List<Tirage>, val regles: String = "")

private val UNE = Tirage("Une carte", "Une réponse simple, ou le conseil du jour.", listOf("Le message"))
private val TROIS = Tirage("Passé · Présent · Futur", "Le tirage classique pour lire une situation dans le temps.", listOf("Passé", "Présent", "Futur"))
private val CROIX = Tirage(
    "La croix", "Cinq cartes pour comprendre une situation en profondeur.",
    listOf("La situation", "Ce qui s'en va", "Ce qui arrive", "Ce qui vous guide", "Ce qui vous soutient")
)
private val FER = Tirage(
    "Le fer à cheval", "Sept cartes pour un regard complet sur une question.",
    listOf("Passé", "Présent", "Avenir proche", "Vous", "Votre entourage", "Les obstacles", "Le résultat")
)
private val CELTE = Tirage(
    "La croix celtique", "Le grand tirage en dix cartes pour une question importante.",
    listOf("Le cœur de la situation", "Le défi", "Les racines", "Le passé récent", "L'objectif", "L'avenir proche", "Vous", "Votre entourage", "Espoirs et peurs", "Le résultat")
)

// ── Tirages de l'oracle des anciens dieux ──
private val MIROIR = Tirage(
    "Le Miroir", "Six cartes, deux colonnes face à face : ce que vous vivez et ce qui vous répond.",
    listOf("Intérieur 1", "Intérieur 2", "Intérieur 3", "Extérieur 1", "Extérieur 2", "Extérieur 3"),
    cols = 2,
    rangs = listOf(listOf(0, 3), listOf(1, 4), listOf(2, 5)),
    duos = listOf(0 to 3, 1 to 4, 2 to 5),
    regle = "Colonne de gauche : l'intérieur, le point de départ, ce que vit ou ressent le consultant. Colonne de droite : l'extérieur, la réponse, le défi à relever ou l'impact en face. On lit les duos côte à côte : de la même famille, c'est un accord ; en opposition, c'est le nœud du problème à arbitrer."
)
private val BALANCE = Tirage(
    "La Balance des Mondes", "Neuf cartes autour d'un pivot : le passé d'un côté, l'avenir de l'autre.",
    listOf("Passé 1", "Passé 2", "Passé 3", "Passé 4", "Avenir 1", "Avenir 2", "Avenir 3", "Avenir 4", "Le pivot"),
    cols = 2,
    rangs = listOf(listOf(0, 4), listOf(1, 5), listOf(8), listOf(2, 6), listOf(3, 7)),
    duos = listOf(0 to 4, 1 to 5, 2 to 6, 3 to 7),
    pivot = 8,
    regle = "À gauche, quatre cartes : le passé, les racines, les forces acquises. À droite, quatre cartes : l'avenir, les projections, les obstacles extérieurs. Au centre, la carte pivot ou synthèse fait pencher la balance. On lit l'alliance ou l'opposition des duos, reliés ou tranchés par le pivot."
)
private val VOIE14 = Tirage(
    "La Voie des 14", "Le grand tirage : sept cartes du Ciel et sept cartes de la Terre.",
    listOf("Ciel 1", "Ciel 2", "Ciel 3", "Ciel 4", "Ciel 5", "Ciel 6", "Ciel 7", "Terre 1", "Terre 2", "Terre 3", "Terre 4", "Terre 5", "Terre 6", "Terre 7"),
    cols = 2,
    rangs = (0..6).map { listOf(it, it + 7) },
    duos = (0..6).map { it to it + 7 },
    groupes = listOf("la ligne du Ciel" to (0..6).toList(), "la ligne de la Terre" to (7..13).toList()),
    regle = "Deux lignes de sept cartes. Ligne du Ciel (à gauche) : le conscient, les forces visibles, la surface. Ligne de la Terre (à droite) : l'inconscient, les forces cachées, les profondeurs. À l'écran, les cartes se présentent en sept duos Ciel/Terre, de haut en bas. Les duos font s'allier ou s'affronter les deux niveaux ; chaque ligne révèle ses blocs de force."
)

private const val REGLES_DIEUX = "Les 44 cartes se répartissent en 11 familles transversales : Ciel, Tempête, Sagesse, Passion, Quête, Lumière, Ombre, Joie, Terre, Création et Protection.\n\nL'Addition (synergie et écho culturel) : quand deux cartes de la même famille ou de la même dynamique se rencontrent, leurs énergies s'additionnent et se renforcent. C'est la signature d'une loi universelle incontournable.\n\nLe Combat (tension et ajustement) : quand des forces contraires se font face, par exemple une tempête active devant une sagesse souterraine, elles créent un défi ou un équilibre dynamique. L'une vient challenger, nuancer ou canaliser l'autre pour trouver la juste voie."

val DECKS = listOf(
    Deck("edmond", "Oracle du mage Edmond", "L'oracle du mage Edmond : 53 cartes, quatre cartes fondatrices et les sept planètes, pour répondre à vos questions.", EDMOND, listOf(UNE, TROIS, CROIX)),
    Deck("dieux", "Oracle des anciens dieux", "44 cartes, quatre traditions antiques (sumérienne, védique, chinoise, égyptienne archaïque), onze cartes chacune.", DIEUX, listOf(MIROIR, BALANCE, VOIE14), REGLES_DIEUX),
    Deck("rws", "Tarot Rider-Waite-Smith", "Le tarot le plus connu, illustré de scènes pour chacune de ses 78 cartes.", emptyList(), listOf(UNE, TROIS, FER, CELTE))
)
