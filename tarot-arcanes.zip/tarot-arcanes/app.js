const POS=["Passé","Présent","Futur"];
const FONDS=["lune-pleine","croissant","eclipse","phases","aurore"].map(f=>`fonds/${f}.svg`);
let tirage=[],fond=-1;
const $=s=>document.querySelector(s);
function rnd(s){return()=>(s=(s*9301+49297)%233280)/233280}
function faceSVG(c){const r=rnd(c.n+3),h=(c.n*37+220)%360;let st='';
for(let i=0;i<18;i++)st+=`<circle cx="${10+r()*180}" cy="${50+r()*200}" r="${.6+r()*1.6}" fill="#f4e4b0" opacity="${.4+r()*.6}"/>`;
return `<svg viewBox="0 0 200 340" role="img" aria-label="${c.nom}"><defs><linearGradient id="g${c.n}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(${h},55%,18%)"/><stop offset="1" stop-color="hsl(${(h+50)%360},60%,7%)"/></linearGradient></defs>
<rect width="200" height="340" rx="14" fill="url(#g${c.n})"/><rect x="8" y="8" width="184" height="324" rx="10" fill="none" stroke="#d9b45a" stroke-width="1.5"/><rect x="14" y="14" width="172" height="312" rx="7" fill="none" stroke="#d9b45a" stroke-width=".5" opacity=".6"/>${st}
<circle cx="100" cy="160" r="66" fill="none" stroke="#d9b45a" stroke-width=".8"/><circle cx="100" cy="160" r="55" fill="hsl(${h},50%,24%)" opacity=".7"/>
<path d="M100 108a52 52 0 1 0 0 104a38 38 0 1 1 0-104z" fill="#f1dfa2" opacity=".2"/>
<text x="100" y="182" text-anchor="middle" font-size="54" fill="#f6e7b4" font-family="serif">${c.g}</text>
<text x="100" y="44" text-anchor="middle" font-size="20" fill="#d9b45a" font-family="Georgia,serif">${ROM[c.n]}</text>
<text x="100" y="298" text-anchor="middle" font-size="15" fill="#f6e7b4" font-family="Georgia,serif">${c.nom}</text></svg>`}
function dosSVG(){return `<svg viewBox="0 0 200 340"><rect width="200" height="340" rx="14" fill="#14103a"/><rect x="8" y="8" width="184" height="324" rx="10" fill="none" stroke="#d9b45a" stroke-width="1.5"/>
<circle cx="100" cy="170" r="52" fill="none" stroke="#d9b45a"/><circle cx="100" cy="170" r="38" fill="none" stroke="#d9b45a" opacity=".5"/>
<path d="M100 130a40 40 0 1 0 0 80a30 30 0 1 1 0-80z" fill="#f1dfa2" opacity=".85"/><circle cx="60" cy="90" r="2" fill="#f6e7b4"/><circle cx="145" cy="250" r="2" fill="#f6e7b4"/><circle cx="150" cy="95" r="1.5" fill="#f6e7b4"/><circle cx="50" cy="245" r="1.5" fill="#f6e7b4"/></svg>`}
function changerFond(){let i;do{i=Math.floor(Math.random()*FONDS.length)}while(i===fond);fond=i;$("#bg").style.backgroundImage=`url(${FONDS[i]})`}
function tirer(){
 const p=[...CARTES].sort(()=>Math.random()-.5).slice(0,3);tirage=p;changerFond();
 const z=$("#cartes");z.innerHTML="";$("#encart").hidden=true;
 p.forEach((c,i)=>{const s=document.createElement("div");s.className="slot";
  s.innerHTML=`<div class="pos">${POS[i]}</div><button class="carte" aria-label="Ouvrir ${c.nom}"><div class="inner"><div class="dos">${dosSVG()}</div><div class="face">${faceSVG(c)}</div></div></button><div class="nom"></div>`;
  s.querySelector(".carte").onclick=()=>{location.hash="carte-"+c.n};z.appendChild(s);
  setTimeout(()=>{s.querySelector(".carte").classList.add("flip");s.querySelector(".nom").textContent=c.nom},500+i*700)});
 setTimeout(lecture,500+3*700);
}
function lecture(){
 let h="";tirage.forEach((c,i)=>{h+=`<p><strong>${POS[i]} — ${c.nom}.</strong> Cette carte parle de ${c.m}. ${c.c}</p>`});
 h+=`<p><em>Lisez les trois cartes comme une histoire : ce qui vous a menés ici, ce que vous vivez, ce qui s'ouvre. Touchez une carte pour lire sa signification complète.</em></p>`;
 $("#lecture").innerHTML=h;$("#encart").hidden=false;$("#encart").scrollIntoView({behavior:"smooth",block:"nearest"});
}
function route(){const m=location.hash.match(/^#carte-(\d+)$/),c=m&&CARTES[+m[1]];
 $("#tirage").hidden=!!c;$("#detail").hidden=!c;window.scrollTo(0,0);
 if(c)$("#fiche").innerHTML=`<div class="grand">${faceSVG(c)}</div><div class="texte"><h2>${ROM[c.n]} · ${c.nom}</h2><p><strong>Mots-clés :</strong> ${c.m}.</p><p>${c.d}</p><p><strong>Conseil :</strong> ${c.c}</p></div>`}
$("#btn").onclick=tirer;$("#retour").onclick=()=>{location.hash="";history.replaceState(null,"",location.pathname);route()};
window.addEventListener("hashchange",route);changerFond();route();
