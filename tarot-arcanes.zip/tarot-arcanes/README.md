# Les Arcanes — tirage de cartes
Site statique (HTML/CSS/JS), sans dépendance. Ouvrez `index.html` ou déployez sur GitHub Pages.
- `data.js` : les 22 arcanes majeurs (textes modifiables)
- `fonds/` : 5 fonds SVG (un différent à chaque tirage), remplaçables par vos propres images
- `app.js` : tirage, encart d'explication, page de détail par carte
