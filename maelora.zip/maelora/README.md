# Maelora

Application Android de cartomancie (Kotlin + Jetpack Compose).

## Jeux
Tarot de Marseille, Petit Lenormand, Tarot Rider-Waite-Smith, Jeu de 32 cartes.
Grand Etteilla : tirages prêts, liste des cartes à documenter (jeu grisé dans l'appli).

## Organisation du code (app/src/main/java/com/maelora)
- model/           : cartes, jeux, tirages
- engine/          : moteur de tirage (sans doublons, tirage du jour)
- interpretation/  : moteur d'interprétation traditionnel (point de départ)
- ai/              : consigne envoyée à l'IA + fournisseur de lecture
- data/            : lecture des JSON, préférences
- ui/              : écrans Compose

Les jeux et les tirages sont dans app/src/main/assets/decks/ (un JSON par jeu).
Les tests du moteur sont dans app/src/test/.

## Pas encore fait
Illustrations, significations des cartes, interprétation par IA, historique des tirages.
