package com.maelora.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import kotlin.random.Random

class DrawEngineTest {

    private val ids = (1..36).map { "c$it" }

    @Test
    fun drawReturnsRequestedCountWithoutDuplicates() {
        for (count in listOf(1, 3, 9, 36)) {
            val drawn = DrawEngine.draw(ids, count, false, Random(42))
            assertEquals(count, drawn.size)
            assertEquals(count, drawn.map { it.cardId }.toSet().size)
        }
    }

    @Test
    fun positionsFollowDrawOrder() {
        val drawn = DrawEngine.draw(ids, 5, false, Random(1))
        assertEquals(listOf(0, 1, 2, 3, 4), drawn.map { it.positionIndex })
    }

    @Test
    fun noReversedCardWhenNotAllowed() {
        val drawn = DrawEngine.draw(ids, 36, false, Random(7))
        assertTrue(drawn.none { it.reversed })
    }

    @Test
    fun invalidCountIsRejected() {
        try {
            DrawEngine.draw(ids, 37, false, Random(1))
            fail("Un nombre de cartes supérieur au jeu doit être refusé")
        } catch (e: IllegalArgumentException) {
            // attendu
        }
    }

    @Test
    fun dailyDrawIsStableForSameDay() {
        val a = DrawEngine.dailyDraw(ids, "lenormand", "2026-10-28", "salt", false)
        val b = DrawEngine.dailyDraw(ids, "lenormand", "2026-10-28", "salt", false)
        assertEquals(a, b)
    }
}
