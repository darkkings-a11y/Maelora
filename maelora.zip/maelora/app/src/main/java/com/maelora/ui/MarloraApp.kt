package com.maelora.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.maelora.data.DeckRepository
import com.maelora.data.Prefs
import com.maelora.engine.DrawEngine
import com.maelora.model.DrawnCard
import com.maelora.model.Spread
import com.maelora.model.SpreadPosition
import java.time.LocalDate
import kotlin.random.Random

sealed interface Screen {
    object Home : Screen
    data class DeckMenu(val deckId: String) : Screen
    data class Reading(
        val deckId: String,
        val spread: Spread,
        val drawn: List<DrawnCard>,
    ) : Screen
}

private val DailySpread = Spread(
    id = "jour",
    name = "Tirage du jour",
    description = "Une carte, la même toute la journée.",
    origin = "moderne",
    positions = listOf(SpreadPosition("Carte du jour")),
)

@Composable
fun MaeloraApp() {
    val context = LocalContext.current
    val decks = remember { DeckRepository(context).loadAll() }
    val prefs = remember { Prefs(context) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    BackHandler(enabled = screen !is Screen.Home) {
        val current = screen
        screen = if (current is Screen.Reading) Screen.DeckMenu(current.deckId) else Screen.Home
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        when (val s = screen) {
            is Screen.Home -> HomeScreen(
                decks = decks,
                onSelect = { deck -> screen = Screen.DeckMenu(deck.id) },
            )

            is Screen.DeckMenu -> {
                val deck = decks.first { it.id == s.deckId }
                DeckMenuScreen(
                    deck = deck,
                    onDaily = {
                        val card = DrawEngine.dailyDraw(
                            cardIds = deck.cardIds,
                            deckId = deck.id,
                            dateIso = LocalDate.now().toString(),
                            salt = prefs.salt,
                            allowReversed = deck.allowReversed,
                        )
                        screen = Screen.Reading(deck.id, DailySpread, listOf(card))
                    },
                    onSpread = { spread ->
                        val drawn = DrawEngine.draw(
                            cardIds = deck.cardIds,
                            count = spread.size,
                            allowReversed = deck.allowReversed,
                            random = Random.Default,
                        )
                        screen = Screen.Reading(deck.id, spread, drawn)
                    },
                    onBack = { screen = Screen.Home },
                )
            }

            is Screen.Reading -> {
                val deck = decks.first { it.id == s.deckId }
                ReadingScreen(
                    deck = deck,
                    spread = s.spread,
                    drawn = s.drawn,
                    onBack = { screen = Screen.DeckMenu(deck.id) },
                )
            }
        }
    }
}
