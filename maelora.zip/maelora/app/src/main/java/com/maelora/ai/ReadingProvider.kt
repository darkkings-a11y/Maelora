package com.maelora.ai

/** Service d'interprétation : remplaçable (IA distante, modèle local, mode hors ligne). */
interface ReadingProvider {
    suspend fun interpret(prompt: String): String
}

class OfflineReadingProvider : ReadingProvider {
    override suspend fun interpret(prompt: String): String =
        "Mode hors ligne : les interprétations personnalisées par IA ne sont pas encore branchées."
}
