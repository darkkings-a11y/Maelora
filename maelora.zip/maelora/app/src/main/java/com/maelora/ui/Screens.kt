package com.maelora.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import com.maelora.ai.PromptBuilder
import com.maelora.interpretation.ReadingLine
import com.maelora.interpretation.ReadingLines
import com.maelora.model.Deck
import com.maelora.model.DrawnCard
import com.maelora.model.Spread

@Composable
fun HomeScreen(decks: List<Deck>, onSelect: (Deck) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().safeDrawingPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Maelora", style = MaterialTheme.typography.displaySmall, color = Gold)
                Text(
                    "Cartomancie : une pratique symbolique, pas une prédiction.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        items(decks) { deck -> DeckCard(deck, onSelect) }
    }
}

@Composable
private fun DeckCard(deck: Deck, onSelect: (Deck) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (deck.ready) 1f else 0.5f)
            .clickable(enabled = deck.ready) { onSelect(deck) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(deck.name, style = MaterialTheme.typography.titleLarge, color = Gold)
            Text(
                text = if (deck.ready) {
                    "${deck.cards.size} cartes · ${deck.spreads.size} tirages"
                } else {
                    "Bientôt disponible"
                },
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
fun DeckMenuScreen(
    deck: Deck,
    onDaily: () -> Unit,
    onSpread: (Spread) -> Unit,
    onBack: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().safeDrawingPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column {
                TextButton(onClick = onBack) { Text("← Retour") }
                Text(deck.name, style = MaterialTheme.typography.headlineMedium, color = Gold)
                Text("${deck.cards.size} cartes", style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Button(onClick = onDaily, modifier = Modifier.fillMaxWidth()) {
                Text("Tirage du jour")
            }
        }
        items(deck.spreads) { spread -> SpreadCard(spread, onSpread) }
    }
}

@Composable
private fun SpreadCard(spread: Spread, onSpread: (Spread) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onSpread(spread) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(spread.name, style = MaterialTheme.typography.titleMedium, color = Gold)
            Text(spread.description, style = MaterialTheme.typography.bodyMedium)
            Text(
                "${spread.size} cartes · origine : ${spread.origin}",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
fun ReadingScreen(
    deck: Deck,
    spread: Spread,
    drawn: List<DrawnCard>,
    onBack: () -> Unit,
) {
    val lines = remember(deck, spread, drawn) { ReadingLines.build(deck, spread, drawn) }
    var showPrompt by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().safeDrawingPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column {
                TextButton(onClick = onBack) { Text("← Retour") }
                Text(spread.name, style = MaterialTheme.typography.headlineMedium, color = Gold)
                Text(
                    "${deck.name} · origine : ${spread.origin}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        items(lines) { line -> LineRow(line) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { showPrompt = !showPrompt },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (showPrompt) "Masquer le prompt IA" else "Voir le prompt IA")
                }
                if (showPrompt) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Text(
                            text = PromptBuilder.build(deck, spread, drawn, null),
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                Text(
                    "Les interprétations détaillées arriveront dans une prochaine version.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun LineRow(line: ReadingLine) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CardTile(number = line.card.number, name = line.card.name, reversed = line.reversed)
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(line.positionName, style = MaterialTheme.typography.titleSmall, color = Gold)
            if (line.positionHint.isNotBlank()) {
                Text(line.positionHint, style = MaterialTheme.typography.bodySmall)
            }
            Text(
                text = if (line.reversed) "${line.card.name} (inversée)" else line.card.name,
                style = MaterialTheme.typography.titleMedium,
            )
        }
    }
}
