package com.maelora.ai

import com.maelora.interpretation.ReadingLines
import com.maelora.model.Deck
import com.maelora.model.DrawnCard
import com.maelora.model.Spread

/**
 * Construit la consigne envoyée à l'IA (distante ou locale).
 * L'IA ne "sait" rien de plus que ce qu'on lui donne ici : jeu, tirage,
 * positions, cartes, question.
 */
object PromptBuilder {

    fun build(
        deck: Deck,
        spread: Spread,
        drawn: List<DrawnCard>,
        question: String?,
    ): String {
        val sb = StringBuilder()
        sb.appendLine("Tu es un lecteur de cartes expérimenté. Jeu utilisé : ${deck.name}.")
        sb.appendLine("Tirage : ${spread.name} (${spread.origin}).")
        if (!question.isNullOrBlank()) {
            sb.appendLine("Question de la personne : $question")
        }
        sb.appendLine()
        sb.appendLine("Cartes tirées, dans l'ordre des positions :")
        for (line in ReadingLines.build(deck, spread, drawn)) {
            val orientation = if (line.reversed) " (inversée)" else ""
            val hint = if (line.positionHint.isBlank()) "" else " — ${line.positionHint}"
            sb.appendLine("- ${line.positionName}$hint : ${line.card.name}$orientation")
        }
        sb.appendLine()
        sb.appendLine("Règles :")
        sb.appendLine("- N'invente aucune règle traditionnelle.")
        sb.appendLine("- Sépare clairement le sens traditionnel de tes propres interprétations.")
        sb.appendLine("- Présente la lecture comme une pratique symbolique, jamais comme une prédiction garantie.")
        return sb.toString()
    }
}
