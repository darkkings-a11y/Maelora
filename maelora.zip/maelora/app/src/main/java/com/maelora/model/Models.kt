package com.maelora.model

data class Card(
    val id: String,
    val number: String,
    val name: String,
)

data class SpreadPosition(
    val name: String,
    val hint: String = "",
)

data class Spread(
    val id: String,
    val name: String,
    val description: String,
    val origin: String,
    val positions: List<SpreadPosition>,
) {
    val size: Int get() = positions.size
}

data class Deck(
    val id: String,
    val name: String,
    val order: Int,
    val ready: Boolean,
    val allowReversed: Boolean,
    val cards: List<Card>,
    val spreads: List<Spread>,
) {
    fun card(id: String): Card = cards.first { it.id == id }
    val cardIds: List<String> get() = cards.map { it.id }
}

data class DrawnCard(
    val cardId: String,
    val positionIndex: Int,
    val reversed: Boolean,
)
