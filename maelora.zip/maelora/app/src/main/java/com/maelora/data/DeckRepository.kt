package com.maelora.data

import android.content.Context
import com.maelora.model.Card
import com.maelora.model.Deck
import com.maelora.model.Spread
import com.maelora.model.SpreadPosition
import org.json.JSONObject

/** Charge les jeux depuis assets/decks/*.json (un fichier par jeu). */
class DeckRepository(private val context: Context) {

    fun loadAll(): List<Deck> {
        val files = context.assets.list("decks")?.filter { it.endsWith(".json") } ?: emptyList()
        return files
            .map { parse(readAsset("decks/$it")) }
            .sortedBy { it.order }
    }

    private fun readAsset(path: String): String =
        context.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun parse(text: String): Deck {
        val o = JSONObject(text)

        val cardsArray = o.getJSONArray("cards")
        val cards = (0 until cardsArray.length()).map { i ->
            val c = cardsArray.getJSONObject(i)
            Card(c.getString("id"), c.getString("number"), c.getString("name"))
        }

        val spreadsArray = o.getJSONArray("spreads")
        val spreads = (0 until spreadsArray.length()).map { i ->
            val s = spreadsArray.getJSONObject(i)
            val positionsArray = s.getJSONArray("positions")
            val positions = (0 until positionsArray.length()).map { j ->
                val p = positionsArray.getJSONObject(j)
                SpreadPosition(p.getString("name"), p.optString("hint", ""))
            }
            Spread(
                id = s.getString("id"),
                name = s.getString("name"),
                description = s.getString("description"),
                origin = s.getString("origin"),
                positions = positions,
            )
        }

        return Deck(
            id = o.getString("id"),
            name = o.getString("name"),
            order = o.getInt("order"),
            ready = o.getBoolean("ready"),
            allowReversed = o.getBoolean("allowReversed"),
            cards = cards,
            spreads = spreads,
        )
    }
}
