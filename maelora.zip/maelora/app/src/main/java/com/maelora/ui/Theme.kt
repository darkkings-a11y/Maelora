package com.maelora.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFC9A24B)
val Night = Color(0xFF14182B)
val NightLight = Color(0xFF1F2547)
val Parchment = Color(0xFFF1E6C8)

private val MaeloraColors = darkColorScheme(
    primary = Gold,
    onPrimary = Night,
    secondary = Gold,
    onSecondary = Night,
    background = Night,
    onBackground = Parchment,
    surface = NightLight,
    onSurface = Parchment,
)

@Composable
fun MaeloraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MaeloraColors, content = content)
}
