package com.maelora.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Famille d'une carte, déduite de son identifiant (maj_, baton_, coeur_, len_...). */
private enum class Family { MAJOR, WANDS, CUPS, SWORDS, COINS, HEARTS, DIAMONDS, CLUBS, SPADES, LENORMAND }

private fun familyOf(cardId: String): Family = when {
    cardId.startsWith("maj_") -> Family.MAJOR
    cardId.startsWith("baton_") -> Family.WANDS
    cardId.startsWith("coupe_") -> Family.CUPS
    cardId.startsWith("epee_") -> Family.SWORDS
    cardId.startsWith("denier_") || cardId.startsWith("pentacle_") -> Family.COINS
    cardId.startsWith("coeur_") -> Family.HEARTS
    cardId.startsWith("carreau_") -> Family.DIAMONDS
    cardId.startsWith("trefle_") -> Family.CLUBS
    cardId.startsWith("pique_") -> Family.SPADES
    else -> Family.LENORMAND
}

private fun isPlayingCard(f: Family) =
    f == Family.HEARTS || f == Family.DIAMONDS || f == Family.CLUBS || f == Family.SPADES

private class Palette(val top: Color, val bottom: Color, val accent: Color, val ink: Color)

private val RedSuit = Color(0xFFB3262E)
private val BlackSuit = Color(0xFF1D1D24)

private fun paletteOf(f: Family): Palette = when (f) {
    Family.MAJOR -> Palette(Color(0xFF2E3478), Color(0xFF14182B), Gold, Parchment)
    Family.WANDS -> Palette(Color(0xFF225740), Color(0xFF0F2A20), Color(0xFF86D9A3), Parchment)
    Family.CUPS -> Palette(Color(0xFF244777), Color(0xFF0E203B), Color(0xFF86BDF5), Parchment)
    Family.SWORDS -> Palette(Color(0xFF414859), Color(0xFF1B1F29), Color(0xFFD0D8E6), Parchment)
    Family.COINS -> Palette(Color(0xFF65491A), Color(0xFF2E200B), Color(0xFFE6BE52), Parchment)
    Family.LENORMAND -> Palette(Color(0xFF702F55), Color(0xFF2E1222), Gold, Parchment)
    Family.HEARTS, Family.DIAMONDS -> Palette(Color(0xFFFBF5E6), Color(0xFFEFE3C6), RedSuit, RedSuit)
    Family.CLUBS, Family.SPADES -> Palette(Color(0xFFFBF5E6), Color(0xFFEFE3C6), BlackSuit, BlackSuit)
}

/** Carte dessinée en Compose, en attendant les vraies illustrations. */
@Composable
fun CardTile(
    cardId: String,
    number: String,
    name: String,
    reversed: Boolean,
    modifier: Modifier = Modifier,
) {
    val family = familyOf(cardId)
    val pal = paletteOf(family)
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .size(width = 96.dp, height = 150.dp)
            .rotate(if (reversed) 180f else 0f)
            .shadow(6.dp, shape)
            .background(Brush.verticalGradient(listOf(pal.top, pal.bottom)), shape)
            .border(1.5.dp, pal.accent, shape)
            .padding(5.dp)
            .border(0.5.dp, pal.accent.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(4.dp),
    ) {
        if (isPlayingCard(family)) {
            PlayingFace(family, pal, number)
        } else {
            TarotFace(family, pal, number, name)
        }
    }
}

@Composable
private fun TarotFace(family: Family, pal: Palette, number: String, name: String) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = number,
            color = pal.accent,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = if (number.length <= 3) 18.sp else 10.sp,
            maxLines = 1,
        )
        Emblem(family, pal.accent, Modifier.size(if (family == Family.MAJOR) 54.dp else 44.dp))
        Text(
            text = name,
            color = pal.ink,
            fontFamily = FontFamily.Serif,
            fontSize = 9.sp,
            lineHeight = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun PlayingFace(family: Family, pal: Palette, number: String) {
    val label = when (number) {
        "Valet" -> "V"
        "Dame" -> "D"
        "Roi" -> "R"
        "As" -> "A"
        else -> number
    }
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.align(Alignment.TopStart),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = label,
                color = pal.ink,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            )
            Emblem(family, pal.ink, Modifier.size(12.dp))
        }
        Emblem(family, pal.ink, Modifier.align(Alignment.Center).size(46.dp))
        Column(
            modifier = Modifier.align(Alignment.BottomEnd).rotate(180f),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = label,
                color = pal.ink,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            )
            Emblem(family, pal.ink, Modifier.size(12.dp))
        }
    }
}

@Composable
private fun Emblem(family: Family, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) { drawEmblem(family, color) }
}

private fun DrawScope.drawEmblem(family: Family, color: Color) {
    val w = size.width
    val h = size.height
    when (family) {
        Family.HEARTS -> drawPath(heartPath(w, h * 0.9f, false), color)

        Family.DIAMONDS -> {
            val p = Path().apply {
                moveTo(w * 0.5f, 0f)
                lineTo(w * 0.92f, h * 0.5f)
                lineTo(w * 0.5f, h)
                lineTo(w * 0.08f, h * 0.5f)
                close()
            }
            drawPath(p, color)
        }

        Family.CLUBS -> {
            drawCircle(color, w * 0.22f, Offset(w * 0.5f, h * 0.27f))
            drawCircle(color, w * 0.22f, Offset(w * 0.27f, h * 0.56f))
            drawCircle(color, w * 0.22f, Offset(w * 0.73f, h * 0.56f))
            drawPath(stemPath(w, h, 0.5f), color)
        }

        Family.SPADES -> {
            drawPath(heartPath(w, h * 0.8f, true), color)
            drawPath(stemPath(w, h, 0.62f), color)
        }

        Family.CUPS -> {
            val cup = Path().apply {
                moveTo(w * 0.12f, h * 0.08f)
                lineTo(w * 0.88f, h * 0.08f)
                cubicTo(w * 0.88f, h * 0.5f, w * 0.66f, h * 0.58f, w * 0.54f, h * 0.62f)
                lineTo(w * 0.54f, h * 0.82f)
                lineTo(w * 0.72f, h * 0.9f)
                lineTo(w * 0.72f, h * 0.96f)
                lineTo(w * 0.28f, h * 0.96f)
                lineTo(w * 0.28f, h * 0.9f)
                lineTo(w * 0.46f, h * 0.82f)
                lineTo(w * 0.46f, h * 0.62f)
                cubicTo(w * 0.34f, h * 0.58f, w * 0.12f, h * 0.5f, w * 0.12f, h * 0.08f)
                close()
            }
            drawPath(cup, color)
        }

        Family.SWORDS -> {
            val blade = Path().apply {
                moveTo(w * 0.5f, 0f)
                lineTo(w * 0.6f, h * 0.12f)
                lineTo(w * 0.6f, h * 0.66f)
                lineTo(w * 0.4f, h * 0.66f)
                lineTo(w * 0.4f, h * 0.12f)
                close()
            }
            drawPath(blade, color)
            drawLine(color, Offset(w * 0.18f, h * 0.7f), Offset(w * 0.82f, h * 0.7f), w * 0.09f, StrokeCap.Round)
            drawLine(color, Offset(w * 0.5f, h * 0.7f), Offset(w * 0.5f, h * 0.9f), w * 0.08f, StrokeCap.Round)
            drawCircle(color, w * 0.06f, Offset(w * 0.5f, h * 0.94f))
        }

        Family.WANDS -> {
            drawLine(color, Offset(w * 0.3f, h), Offset(w * 0.7f, h * 0.05f), w * 0.12f, StrokeCap.Round)
            drawCircle(color, w * 0.1f, Offset(w * 0.72f, h * 0.38f))
            drawCircle(color, w * 0.1f, Offset(w * 0.36f, h * 0.5f))
            drawCircle(color, w * 0.08f, Offset(w * 0.66f, h * 0.68f))
        }

        Family.COINS -> {
            val c = Offset(w * 0.5f, h * 0.5f)
            drawCircle(color, w * 0.46f, c, style = Stroke(width = w * 0.05f))
            drawCircle(color, w * 0.35f, c, style = Stroke(width = w * 0.025f))
            drawPath(starPath(c.x, c.y, w * 0.24f), color)
        }

        Family.MAJOR -> {
            val c = Offset(w * 0.5f, h * 0.5f)
            drawCircle(color, w * 0.2f, c)
            for (i in 0 until 12) {
                val ang = i * 2.0 * PI / 12.0
                val r1 = w * 0.3f
                val r2 = if (i % 2 == 0) w * 0.48f else w * 0.4f
                val a = Offset(c.x + (r1 * cos(ang)).toFloat(), c.y + (r1 * sin(ang)).toFloat())
                val b = Offset(c.x + (r2 * cos(ang)).toFloat(), c.y + (r2 * sin(ang)).toFloat())
                drawLine(color, a, b, w * 0.035f, StrokeCap.Round)
            }
        }

        Family.LENORMAND -> {
            val c = Offset(w * 0.5f, h * 0.5f)
            val diamond = Path().apply {
                moveTo(w * 0.5f, 0f)
                lineTo(w * 0.95f, h * 0.5f)
                lineTo(w * 0.5f, h)
                lineTo(w * 0.05f, h * 0.5f)
                close()
            }
            drawPath(diamond, color, style = Stroke(width = w * 0.04f))
            drawPath(starPath(c.x, c.y, w * 0.2f, 4, 0.4f), color)
        }
    }
}

/** Cœur ; avec flip = true, pointe vers le haut (pique). */
private fun heartPath(w: Float, h: Float, flip: Boolean): Path {
    fun y(v: Float): Float = if (flip) h - v else v
    return Path().apply {
        moveTo(w * 0.5f, y(h))
        cubicTo(-w * 0.2f, y(h * 0.55f), w * 0.1f, y(-h * 0.1f), w * 0.5f, y(h * 0.28f))
        cubicTo(w * 0.9f, y(-h * 0.1f), w * 1.2f, y(h * 0.55f), w * 0.5f, y(h))
        close()
    }
}

/** Petit pied triangulaire de trèfle ou de pique. */
private fun stemPath(w: Float, h: Float, startY: Float): Path = Path().apply {
    moveTo(w * 0.5f, h * startY)
    lineTo(w * 0.68f, h)
    lineTo(w * 0.32f, h)
    close()
}

private fun starPath(cx: Float, cy: Float, r: Float, points: Int = 5, inner: Float = 0.42f): Path {
    val p = Path()
    val total = points * 2
    for (i in 0 until total) {
        val ang = -PI / 2.0 + i * PI / points
        val rad = if (i % 2 == 0) r else r * inner
        val x = cx + (rad * cos(ang)).toFloat()
        val y = cy + (rad * sin(ang)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}
