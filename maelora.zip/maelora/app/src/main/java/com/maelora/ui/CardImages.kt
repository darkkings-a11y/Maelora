package com.maelora.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.IOException

private val Extensions = listOf("webp", "jpg", "jpeg", "png")

/**
 * Cherche l'illustration d'une carte dans assets/cards/<jeu>/<carte>.<ext>.
 * Retourne null si aucune image n'existe : la carte dessinée en Compose prend alors le relais.
 * L'image est réduite à la volée pour ne pas charger inutilement de gros fichiers.
 */
fun loadCardImage(context: Context, deckId: String, cardId: String, targetWidthPx: Int): ImageBitmap? {
    for (ext in Extensions) {
        val path = "cards/$deckId/$cardId.$ext"
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= targetWidthPx) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = context.assets.open(path).use { BitmapFactory.decodeStream(it, null, options) }
            if (bitmap != null) return bitmap.asImageBitmap()
        } catch (e: IOException) {
            // Pas d'image avec cette extension : on essaie la suivante.
        }
    }
    return null
}
