package com.maelora.data

import android.content.Context
import java.util.UUID

/** Préférences locales. Pour l'instant : un identifiant aléatoire pour le tirage du jour. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("maelora", Context.MODE_PRIVATE)

    val salt: String
        get() {
            val existing = sp.getString("salt", null)
            if (existing != null) return existing
            val created = UUID.randomUUID().toString()
            sp.edit().putString("salt", created).apply()
            return created
        }
}
