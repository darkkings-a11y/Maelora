package com.maelora.interpretation

import com.maelora.model.Card
import com.maelora.model.Deck
import com.maelora.model.DrawnCard
import com.maelora.model.Spread

data class ReadingLine(
    val positionName: String,
    val positionHint: String,
    val card: Card,
    val reversed: Boolean,
)

/**
 * Point de départ du moteur d'interprétation traditionnel.
 * Pour l'instant : associe chaque carte tirée à sa position.
 * Les significations, associations et règles par jeu viendront ici.
 */
object ReadingLines {
    fun build(deck: Deck, spread: Spread, drawn: List<DrawnCard>): List<ReadingLine> =
        drawn.map { d ->
            val position = spread.positions[d.positionIndex]
            ReadingLine(
                positionName = position.name,
                positionHint = position.hint,
                card = deck.card(d.cardId),
                reversed = d.reversed,
            )
        }
}
