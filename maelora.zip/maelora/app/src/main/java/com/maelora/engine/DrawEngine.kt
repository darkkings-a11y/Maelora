package com.maelora.engine

import com.maelora.model.DrawnCard
import kotlin.random.Random

/**
 * Moteur de tirage : il choisit et dispose les cartes, rien d'autre.
 * L'interprétation est dans d'autres modules.
 */
object DrawEngine {

    /** Tire [count] cartes différentes dans [cardIds]. */
    fun draw(
        cardIds: List<String>,
        count: Int,
        allowReversed: Boolean,
        random: Random,
    ): List<DrawnCard> {
        require(count in 1..cardIds.size) {
            "Nombre de cartes invalide : $count pour un jeu de ${cardIds.size} cartes"
        }
        return cardIds
            .shuffled(random)
            .take(count)
            .mapIndexed { index, id ->
                DrawnCard(
                    cardId = id,
                    positionIndex = index,
                    reversed = allowReversed && random.nextBoolean(),
                )
            }
    }

    /** Graine stable pour une même personne (salt), un même jeu et une même date. */
    fun dailySeed(deckId: String, dateIso: String, salt: String): Long {
        var h = 1125899906842597L
        for (c in "$salt|$deckId|$dateIso") {
            h = 31 * h + c.code
        }
        return h
    }

    /** Tirage du jour : la même carte toute la journée pour un même jeu. */
    fun dailyDraw(
        cardIds: List<String>,
        deckId: String,
        dateIso: String,
        salt: String,
        allowReversed: Boolean,
    ): DrawnCard {
        val random = Random(dailySeed(deckId, dateIso, salt))
        return draw(cardIds, 1, allowReversed, random).first()
    }
}
